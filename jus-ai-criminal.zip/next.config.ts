import type { NextConfig } from "next";

const isVercel = process.env.VERCEL === "1" || process.env.VERCEL_ENV !== undefined;

const nextConfig: NextConfig = {
  // Vercel não precisa de standalone output. Local/Docker/VPS usa standalone.
  output: isVercel ? undefined : "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Permite imagens de fontes externas (Google Fonts, Material Icons)
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "fonts.googleapis.com" },
      { protocol: "https", hostname: "sfile.chatglm.cn" },
    ],
  },
};

export default nextConfig;
