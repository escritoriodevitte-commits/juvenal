// Catálogo de tipos de audiência criminal + templates de perguntas
// Para uso na aba Audiências com captura ao vivo

export interface HearingType {
  id: string;
  name: string;
  legalBasis: string;
  description: string;
  participants: string[];
  duration: string;
  goal: string;
  keyTips: string[];
}

export const HEARING_TYPES: HearingType[] = [
  {
    id: "custodia",
    name: "Audiência de Custódia",
    legalBasis: "Resolução CNJ 213/2015 · Lei 13.890/2019",
    description: "Primeira apresentação do preso ao juiz, em até 24h. Controle da legalidade da prisão e prevenção à tortura.",
    participants: ["Juiz", "Acusado", "Defensor", "MP", "Policial responsável"],
    duration: "10-30 minutos",
    goal: "Obter relaxamento da prisão, liberdade provisória, ou conversão em preventiva fundamentada.",
    keyTips: [
      "Arguir ilegalidade do flagrante (art. 302 CPP)",
      "Questionar condições da prisão e possível tortura",
      "Pedir entrevista reservada com o cliente antes",
      "Sugerir medida cautelar diversa (art. 319 CPP)",
      "Citar audiência como momento para relaxar (art. 310, I CPP)",
    ],
  },
  {
    id: "instrucao",
    name: "Audiência de Instrução e Julgamento",
    legalBasis: "Art. 400 e 399, CPP (rito ordinário) · Art. 531 (sumário)",
    description: "Oitiva de testemunhas, ofendido, peritos, interrogatório e alegações finais. Momento central da prova oral.",
    participants: ["Juiz", "Acusado", "Defensor", "MP", "Testemunhas (até 8)", "Peritos", "Ofendido"],
    duration: "1-4 horas",
    goal: "Produzir prova favorável e impugnar prova desfavorável. Demonstração de teses defensivas.",
    keyTips: [
      "Ordem do art. 400: ofendido → test. acusação → test. defesa → peritos → acareações → reconhecimento → interrogatório → alegações finais",
      "Cross-examination direto pelo defensor (art. 212 CPP)",
      "Anotar contradições para usar nas alegações finais",
      "Pedir acareamento quando houver contradição relevante",
      "Questionar testemunhas da acusação com perguntas fechadas",
      "Não deixar testemunha da defesa ser intimidada pelo MP",
    ],
  },
  {
    id: "depoimento_especial",
    name: "Depoimento Especial da Vítima",
    legalBasis: "Art. 224-A, CPP · Lei 13.431/2017 (criança/adolescente) · Lei 11.829/2008",
    description: "Oitiva de vítima ou testemunha vulnerável (criança, adolescente, vítima de crimes sexuais) por videoconferência ou sala especial.",
    participants: ["Juiz", "MP", "Defensor", "Psicólogo/Assistente Social", "Vítima (em sala separada)"],
    duration: "30 minutos a 2 horas",
    goal: "Garantir que a defesa técnica não fique à mercê do depoimento sem possibilidade de perguntas. Pedir quebra de depoimento quando viciado.",
    keyTips: [
      "Direito de formular perguntas (indiretas, via juiz ou psicólogo)",
      "Questionar protocolo de escuta (art. 11 da Lei 13.431)",
      "Verificar se houve sugestionabilidade na oitiva",
      "Pedir reprodução simulada do depoimento quando necessário",
      "Atentar para precedentes STJ sobre depoimento sem ferir dignidade da vítima",
    ],
  },
  {
    id: "alegacoes_finais",
    name: "Alegações Finais Orais",
    legalBasis: "Art. 403, §3º e Art. 405, CPP",
    description: "Discurso final da defesa após instrução. 20 minutos prorrogáveis por mais 10. Pode ser substituído por memoriais escritos.",
    participants: ["Juiz", "Defensor", "MP"],
    duration: "20 minutos (prorrogável +10)",
    goal: "Sintetizar a defesa, refutar acusação, demonstrar teses, pedir absolvição.",
    keyTips: [
      "Estrutura: refutação → tese própria → pedido",
      "Citar testemunhas pelo nome — dá credibilidade",
      "Apontar contradições específicas (cita página dos depoimentos)",
      "Não distorcer prova — perde credibilidade",
      "Pedido claro e direto no final",
      "Preparar contra-argumento às teses do MP",
    ],
  },
  {
    id: "sustentacao_oral",
    name: "Sustentação Oral (Tribunal)",
    legalBasis: "Regimento Interno dos Tribunais",
    description: "Sustentação oral em câmara/turma de tribunal (apelação, RESE, HC, etc.). Tempo variável conforme regimento.",
    participants: ["Desembargadores/Ministros", "Defensor", "Procurador/MP"],
    duration: "15-30 minutos (conforme regimento)",
    goal: "Convencer os desembargadores/ministros. Estrutura: preliminares, mérito, pedido.",
    keyTips: [
      "Estudar os precedentes da câmara/turma antes",
      "Identificar o voto-relator e direcionar argumentos",
      "Tempo curto: 3 argumentos-chave no máximo",
      "Citar precedente STJ/STF paradigmático",
      "Não ler — fale olhando para os julgadores",
      "Preparar resposta para perguntas dos julgadores",
    ],
  },
];

// Categorias de notas para captura rápida
export interface NoteCategory {
  id: string;
  label: string;
  color: string;
  icon: string;
  hint: string;
}

export const NOTE_CATEGORIES: NoteCategory[] = [
  { id: "depoimento", label: "Depoimento", color: "gold", icon: "💬", hint: "O que a testemunha disse" },
  { id: "contradicao", label: "Contradição", color: "forensic", icon: "⚡", hint: "Contradiz declaração anterior" },
  { id: "pergunta", label: "Pergunta", color: "primary", icon: "❓", hint: "Pergunta para cross-examination" },
  { id: "nulidade", label: "Nulidade", color: "destructive", icon: "⚠️", hint: "Vício processual identificado" },
  { id: "prova", label: "Prova", color: "gold", icon: "📋", hint: "Prova documental/pericial relevante" },
  { id: "observacao", label: "Observação", color: "muted", icon: "👁️", hint: "Anotação geral de andamento" },
];

// Templates de perguntas por tipo de testemunha
export interface QuestionTemplate {
  category: string;
  label: string;
  questions: string[];
}

export const QUESTION_TEMPLATES: QuestionTemplate[] = [
  {
    category: "testemunha_acusacao",
    label: "Testemunha de acusação",
    questions: [
      "Como você conhece o acusado?",
      "Onde você estava no momento dos fatos?",
      "Qual era a distância entre você e o local?",
      "Como estava a iluminação no local?",
      "Você estava sozinho ou acompanhado?",
      "Já havia consumido álcool ou outras substâncias?",
      "Você tem interesse pessoal neste caso?",
      "Você já foi condenado por crime?",
      "Como você descreveria sua relação com a vítima?",
      "Você recorda exatamente as roupas que o acusado vestia?",
      "Quanto tempo se passou entre os fatos e seu depoimento na polícia?",
      "Você leu seu depoimento na polícia antes de assinar?",
    ],
  },
  {
    category: "testemunha_defesa",
    label: "Testemunha de defesa",
    questions: [
      "Há quanto tempo você conhece o acusado?",
      "Como você descreveria o caráter do acusado?",
      "Onde você estava no dia e horário dos fatos?",
      "Você estava com o acusado no momento alegado?",
      "Pode confirmar a versão apresentada pela defesa?",
      "Você tem conhecimento de algum fato que contrarie a acusação?",
      "Como você soube deste caso?",
      "Você foi procurado pela defesa ou se apresentou espontaneamente?",
    ],
  },
  {
    category: "policial",
    label: "Policial",
    questions: [
      "Você presenciou os fatos ou tomou conhecimento depois?",
      "Como você identificou o acusado?",
      "Qual foi o procedimento de identificação utilizado?",
      "Houve reconhecimento formal com rito do art. 226 CPP?",
      "Como a prova material foi coletada e preservada?",
      "A cadeia de custódia foi documentada (art. 158-A CPP)?",
      "Você preencheu o auto de apresentação e apreensão?",
      "Houve violência durante a abordagem?",
      "Você é o autor do relatório de polícia judiciária?",
      "Qual era a posição geográfica do senhor em relação ao acusado?",
    ],
  },
  {
    category: "perito",
    label: "Perito",
    questions: [
      "Quando o senhor realizou a perícia?",
      "Qual é a sua especialização e registro no conselho?",
      "O material periciado foi recebido com lacre íntegro?",
      "Houve quebra da cadeia de custódia?",
      "O laudo é conclusivo ou sugere outras hipóteses?",
      "Foram colhidas amostras para contraprova?",
      "A metodologia utilizada segue protocolo técnico reconhecido?",
      "Houve possibilidade de contaminação da amostra?",
      "Qual a margem de erro do método utilizado?",
      "Foram respondidos todos os quesitos da defesa?",
    ],
  },
  {
    category: "ofendido",
    label: "Ofendido / Vítima",
    questions: [
      "Pode descrever o que aconteceu, do início ao fim?",
      "Como você reconheceu o acusado como autor?",
      "Houve contato visual direto com o autor?",
      "Quanto tempo durou o episódio?",
      "Você teve oportunidade de observar detalhes físicos do autor?",
      "Houve algum motivo que possa ter influenciado sua identificação?",
      "Você tinha conhecimento prévio do acusado?",
      "Como você estava no momento dos fatos?",
      "Você mencionou algum detalhe diferente em seu depoimento na polícia?",
      "Houve algum tipo de pressão para identificar o acusado?",
    ],
  },
  {
    category: "acusado_interrogatorio",
    label: "Acusado (interrogatório)",
    questions: [
      "Apresentação do acusado e qualificação",
      "Confirma ou não os fatos narrados pela acusação?",
      "Onde estava no momento dos fatos?",
      "Tem conhecimento de quem seja o autor?",
      "Deseja apresentar versão própria dos fatos?",
      "Tem testemunhas a indicar?",
      "Deseja silenciar (art. 5º LXIII CF)?",
      "Deseja confessar formalmente os fatos?",
      "Houve coação ou pressão no inquérito?",
    ],
  },
];

// Modelo de contra-argumentos para teses comuns do MP
export interface CounterArgument {
  mpTese: string;
  defenseStrategy: string;
  legalBasis: string;
}

export const COUNTER_ARGUMENTS: CounterArgument[] = [
  {
    mpTese: "Materialidade comprovada pelo laudo",
    defenseStrategy: "Questionar cadeia de custódia. Laudo sem lacre íntegro perde valor probatório.",
    legalBasis: "Arts. 158-A a 158-F, CPP (Lei 13.964/19)",
  },
  {
    mpTese: "Reconhecimento pela vítima",
    defenseStrategy: "Verificar rito do art. 226 CPP. Reconhecimento sem descrição prévia é nulo.",
    legalBasis: "Art. 226, CPP · Súmula 545 STF",
  },
  {
    mpTese: "Confissão em juízo",
    defenseStrategy: "Verificar se houve assistência da defesa. Confissão retratada tem menor valor.",
    legalBasis: "Art. 197, CPP · Súmula 332 STJ",
  },
  {
    mpTese: "Testemunho de policial",
    defenseStrategy: "Questionar isenção. Policial que participou da operação tem interesse.",
    legalBasis: "Súmula 545 STF · HC STJ 524.599",
  },
  {
    mpTese: "Princípio da livre motivação",
    defenseStrategy: "Motivação deve ser concreta, não abstrata. Citar SV 14 e art. 93 IX CF.",
    legalBasis: "Art. 93, IX, CF · Súmula Vinculante 14",
  },
  {
    mpTese: "Periculosidade do agente",
    defenseStrategy: "Periculosidade não é critério legal para preventiva. Exigir fundamentação concreta.",
    legalBasis: "Art. 312, CPP · Súmula Vinculante 44",
  },
];

export function getHearingType(id: string): HearingType | undefined {
  return HEARING_TYPES.find(h => h.id === id);
}
