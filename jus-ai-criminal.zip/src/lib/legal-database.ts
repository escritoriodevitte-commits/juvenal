// Base local de artigos chave do Código Penal e Processo Penal Brasileiro
// Subset curado pelo treinamento — não substitui a legislação completa

export interface LegalArticle {
  code: "CP" | "CPP" | "CF";
  article: string;
  title?: string;
  text: string;
  note?: string;
  keywords: string[];
}

export const LEGAL_DATABASE: LegalArticle[] = [
  // === CONSTITUIÇÃO FEDERAL ===
  {
    code: "CF",
    article: "5º, XXXVIII",
    title: "Tribunal do Júri",
    text: "é reconhecida a instituição do júri, com a organização que lhe der a lei, assegurados: a) a plenitude de defesa; b) o sigilo das votações; c) a soberania dos veredictos; d) a competência para o julgamento dos crimes dolosos contra a vida.",
    keywords: ["juri", "tribunal do juri", "crimes dolosos contra a vida", "soberania dos veredictos"]
  },
  {
    code: "CF",
    article: "5º, LXI",
    title: "Liberdade provisória",
    text: "ninguém será preso senão em flagrante delito ou por ordem escrita e fundamentada de autoridade judiciária competente, salvo nos casos de transgressão militar ou crime propriamente militar, definidos em lei.",
    keywords: ["prisao", "liberdade provisoria", "flagrante"]
  },
  {
    code: "CF",
    article: "5º, LXIII",
    title: "Direito ao silêncio",
    text: "o preso será informado de seus direitos, entre os quais o de permanecer calado, sendo-lhe assegurada a assistência da família e de advogado.",
    keywords: ["silencio", "direito ao silencio", "preso", "assistencia"]
  },
  // === CÓDIGO PENAL ===
  {
    code: "CP",
    article: "1º",
    title: "Princípio da legalidade",
    text: "Não há crime sem lei anterior que o defina. Não há pena sem prévia cominação legal.",
    note: "Princípio fundamental — nullum crimen sine lege",
    keywords: ["legalidade", "principio", "anterioridade"]
  },
  {
    code: "CP",
    article: "13",
    title: "Relação de causalidade",
    text: "O resultado, de que depende a existência do crime, somente é imputável a quem lhe deu causa. Considera-se causa a ação ou omissão sem a qual o resultado não teria ocorrido.",
    keywords: ["causalidade", "nexo causal", "resultado"]
  },
  {
    code: "CP",
    article: "20",
    title: "Erro sobre elementos do tipo",
    text: "O erro sobre elemento constitutivo do tipo legal de crime exclui o dolo, mas permite a punição por crime culposo, se previsível.",
    keywords: ["erro de tipo", "dolo", "culpa"]
  },
  {
    code: "CP",
    article: "21",
    title: "Erro sobre a ilicitude do fato",
    text: "O desconhecimento da lei é inescusável. O erro sobre a ilicitude do fato, se inevitável, isenta de pena; se evitável, poderá diminuí-la de um sexto a um terço.",
    keywords: ["erro de proibicao", "ilicitude", "inescusavel"]
  },
  {
    code: "CP",
    article: "23",
    title: "Excludentes de ilicitude",
    text: "Não há crime quando o agente pratica o fato: I - em estado de necessidade; II - em legítima defesa; III - em estrito cumprimento de dever legal ou no exercício regular de direito.",
    keywords: ["excludente", "legitima defesa", "estado de necessidade", "estrito cumprimento", "exercicio regular"]
  },
  {
    code: "CP",
    article: "25",
    title: "Legítima defesa",
    text: "Entende-se como legítima defesa quem, usando moderadamente dos meios necessários, repele injusta agressão, atual ou iminente, a direito seu ou de outrem.",
    keywords: ["legitima defesa", "agressao injusta", "moderadamente"]
  },
  {
    code: "CP",
    article: "29",
    title: "Concurso de pessoas",
    text: "Quem, de qualquer modo, concorre para o crime incide nas penas a este cominadas, na medida de sua culpabilidade.",
    keywords: ["concurso de agentes", "coautoria", "participacao"]
  },
  {
    code: "CP",
    article: "33",
    title: "Espécies de pena",
    text: "A pena privativa de liberdade divide-se em reclusão e detenção. As penas restritivas de direitos são: prestação pecuniária, perda de bens e valores, limitação de fim de semana e prestação de serviço à comunidade.",
    keywords: ["pena", "reclusao", "detencao", "restritiva de direitos"]
  },
  {
    code: "CP",
    article: "59",
    title: "Fixação da pena",
    text: "O juiz, atendendo à culpabilidade, aos antecedentes, à conduta social, à personalidade do agente, aos motivos, às circunstâncias e conseqüências do crime, bem como ao comportamento da vítima, estabelecerá, conforme seja necessário e suficiente para reprovação e prevenção do crime.",
    keywords: ["dosimetria", "fixacao da pena", "circunstancias judiciais", "culpabilidade"]
  },
  {
    code: "CP",
    article: "121",
    title: "Homicídio",
    text: "Matar alguém: Pena - reclusão, de seis a vinte anos. §1° Se o agente comete o crime impelido por motivo de relevante valor social ou moral, ou sob o domínio de violenta emoção, logo em seguida a injusta provocação da vítima, o juiz pode reduzir a pena de um sexto a um terço (homicídio privilegiado). §2° Homicídio qualificado: I - mediante paga ou promessa de recompensa; II - por motivo fútil; III - com emprego de veneno, fogo, explosivo, asfixia, tortura ou outro meio insidioso ou cruel; IV - à traição, emboscada, dissimulação; V - para assegurar execução, ocultação, impunidade de outro crime.",
    keywords: ["homicidio", "homicidio privilegiado", "homicidio qualificado", "crime doloso contra a vida"]
  },
  {
    code: "CP",
    article: "129",
    title: "Lesão corporal",
    text: "Ofender a integridade corporal ou a saúde de alguém: Pena - detenção, de três meses a um ano.",
    keywords: ["lesao corporal", "integridade", "saude"]
  },
  {
    code: "CP",
    article: "155",
    title: "Furto",
    text: "Subtrair, para si ou para outrem, coisa alheia móvel: Pena - reclusão, de um a quatro anos, e multa.",
    keywords: ["furto", "subtrair", "coisa alheia movel"]
  },
  {
    code: "CP",
    article: "157",
    title: "Roubo",
    text: "Subtrair coisa móvel alheia, para si ou para outrem, mediante grave ameaça ou violência a pessoa, ou depois de havê-la, por qualquer meio, reduzido à impossibilidade de resistência: Pena - reclusão, de quatro a dez anos, e multa.",
    keywords: ["roubo", "grave ameaca", "violencia", "impossibilidade de resistencia"]
  },
  {
    code: "CP",
    article: "33",
    title: "Tráfico de drogas (Lei 11.343/06 art. 33)",
    text: "Importar, exportar, remeter, preparar, produzir, fabricar, adquirir, vender, expor à venda, oferecer, ter em depósito, transportar, trazer consigo, guardar, prescrever, ministrar ou entregar, a qualquer título, a consumo pessoal drogas sem autorização ou em desacordo com determinação legal ou regulamentar: Pena - reclusão de 5 (cinco) a 15 (quinze) anos e pagamento de 500 (quinhentos) a 1.500 (mil e quinhentos) dias-multa.",
    keywords: ["trafico", "drogas", "lei 11343", "entorpecente"]
  },
  // === CÓDIGO DE PROCESSO PENAL ===
  {
    code: "CPP",
    article: "5º",
    title: "Informação do direito ao silêncio",
    text: "O interrogando será informado do seu direito de permanecer calado e de que suas respostas poderão ser usadas contra ele.",
    keywords: ["silencio", "interrogatorio", "informacao"]
  },
  {
    code: "CPP",
    article: "6º",
    title: "Inquérito policial — competência",
    text: "A autoridade policial que tomar conhecimento da ocorrência procederá à investigação, para averiguar a materialidade e a autoria.",
    keywords: ["inquérito policial", "ip", "investigacao"]
  },
  {
    code: "CPP",
    article: "155",
    title: "Início do procedimento investigatório",
    text: "O inquérito policial inicia-se: I - por meio de requisição da autoridade judiciária ou do Ministério Público; II - mediante requisição do Ministro da Justiça; III - por portaria; IV - por auto de prisão em flagrante; V - por meio de notícia-crime.",
    keywords: ["inquérito", "noticia crime", "portaria", "flagrante"]
  },
  {
    code: "CPP",
    article: "158-A",
    title: "Cadeia de custódia — conceito (Lei 13.964/19)",
    text: "A cadeia de custódia é o conjunto de todos os procedimentos utilizados para manter e documentar a história cronológica do vestígio para fins de prova, permitindo rastrear sua origem, coleta, manuseio, análise, armazenamento e descarte.",
    note: "Instituto introduzido pelo Pacote Anticrime (Lei 13.964/19) — arts. 158-A a 158-F",
    keywords: ["cadeia de custodia", "vestigio", "prova material", "lei 13964", "pacote anticrime"]
  },
  {
    code: "CPP",
    article: "158-B",
    title: "Cadeia de custódia — coleta",
    text: "O vestígio deverá ser coletado de forma a não ser contaminado, devendo ser descrita a origem, as características e o local onde foi encontrado.",
    keywords: ["coleta", "vestigio", "contaminacao"]
  },
  {
    code: "CPP",
    article: "158-F",
    title: "Cadeia de custódia — consequência da falha",
    text: "A não observância da cadeia de custódia não acarreta, necessariamente, a nulidade da prova, mas impede a sua utilização pelo juízo caso se verifique que a irregularidade compromete a sua integridade.",
    note: "Não é nulidade automática — depende de comprometimento da integridade",
    keywords: ["cadeia de custodia", "nulidade", "falha", "integridade"]
  },
  {
    code: "CPP",
    article: "212",
    title: "Perguntas diretamente pelas partes",
    text: "As perguntas das partes serão requeridas ao juiz, que as formulará à testemunha e ao ofendido, podendo, entretanto, as partes formulá-las diretamente, na hipótese do § 1º do art. 224 deste Código, e do art. 222 deste Código, bem como nos julgamentos, nas sessões do tribunal do júri e do juizado especial criminal.",
    keywords: ["oitiva", "perguntas", "testemunha", "cross examination"]
  },
  {
    code: "CPP",
    article: "28-A",
    title: "Acordo de Não Perseguição Penal (Lei 13.964/19)",
    text: "O Ministério Público, com o consentimento do investigado e de seu defensor, poderá propor acordo de não perseguição penal, desde que: I - o crime, sem violência ou grave ameaça, tenha pena mínima inferior a 4 (quatro) anos; II - o investigado não seja reincidente em crime doloso; III - tenha o investigado confessado formalmente e detalhadamente a prática do crime.",
    note: "Redução de pena de 1/4 do mínimo. Pode ser cumulado com suspensão condicional do processo.",
    keywords: ["anpp", "acordo de nao perseguiçao", "lei 13964", "negociaçao penal"]
  },
  {
    code: "CPP",
    article: "400",
    title: "Ordem da instrução no rito ordinário",
    text: "Na audiência de instrução e julgamento, proceder-se-á à tomada de declarações do ofendido, à inquirição das testemunhas arroladas pela acusação e pela defesa, nesta ordem, bem como aos esclarecimentos dos peritos, às acareações, ao reconhecimento de pessoas e coisas e à reprodução simulada dos fatos, dispuserem a inquirição do acusado e, se requerido, à instrução complementar, encerrando com as alegações finais.",
    keywords: ["instruçao", "rito ordinario", "audiencia", "ordem"]
  },
  {
    code: "CPP",
    article: "472",
    title: "Sorteio dos jurados",
    text: "Formado o conselho de sentença, o juiz presidirá os jurados a prestar o compromisso: 'Comprometeis-vos, sob a palavra de honra, de examinar com imparcialidade esta causa e de proferir a vossa decisão conforme a consciência e os ditames da justiça?'.",
    keywords: ["juri", "conselho de sentença", "jurados", "compromisso"]
  },
  {
    code: "CPP",
    article: "474",
    title: "Recusas imotivadas no júri",
    text: "Cada parte poderá recusar, sem motivar, até 3 (três) jurados. As recusas serão feitas, alternadamente, começando pela defesa.",
    keywords: ["juri", "recusa imotivada", "seleçao de jurados"]
  },
  {
    code: "CPP",
    article: "581",
    title: "Cabimento do RESE (rol taxativo)",
    text: "Cabirá recurso, no sentido estrito, da decisão, despacho ou sentença: I - que não receber a denúncia ou a queixa; II - que concluir pela incompetência do juízo; III - que julgar procedentes as exceções, salvo a de suspeição; IV - que pronunciar o réu; V - que conceder, negar, arbitrar, cassar ou julgar inidônea a fiança, indeferir requerimento de prisão preventiva ou revogá-la, conceder liberdade provisória ou relaxar a prisão em flagrante; (...)",
    note: "Lista taxativa — 35 incisos. Decisão fora do rol vai para apelação.",
    keywords: ["rese", "recurso em sentido estrito", "interlocutoria", "rol taxativo"]
  },
  {
    code: "CPP",
    article: "593",
    title: "Cabimento da apelação",
    text: "Cabível apelação: I - das sentenças definitivas de condenação ou absolvição proferidas por juiz singular; II - das decisões definitivas proferidas por juiz absolvido em processo de contravenção; III - das decisões do tribunal do júri, quando: a) ocorrer nulidade posterior à pronúncia; b) a sentença for contrária à prova dos autos; c) for a decisão manifestamente contrária à prova dos autos.",
    note: "No júri: só as 3 hipóteses do inciso III — não se discute mérito dos jurados.",
    keywords: ["apelaçao", "sentença definitiva", "juri", "nulidade"]
  },
  {
    code: "CPP",
    article: "619",
    title: "Embargos de declaração",
    text: "Aos acórdãos proferidos pelos Tribunais de Apelação, câmaras ou turmas, poderão ser opostos embargos de declaração, no prazo de 2 (dois) dias contados da sua publicação, quando houver ambiguidade, obscuridade, contradição ou omissão.",
    keywords: ["embargos de declaraçao", "obscuridade", "contradiçao", "omissao"]
  },
  {
    code: "CPP",
    article: "621",
    title: "Revisão criminal — cabimento",
    text: "A revisão dos processos findos será admitida: I - quando a sentença condenatória for contrária ao texto expresso da lei penal ou à evidência dos autos; II - quando a sentença condenatória se fundar em depoimentos, exames ou documentos comprovadamente falsos; III - quando, após a sentença, se descobrirem novas provas de inocência do condenado ou de circunstância que determine ou autorize diminuição especial da pena.",
    note: "Peça autônoma — não tem prazo. Competência: tribunal que proferiu a decisão.",
    keywords: ["revisao criminal", "transito em julgado", "nova prova", "peça autonomia"]
  },
  {
    code: "CPP",
    article: "647",
    title: "Habeas Corpus — cabimento",
    text: "Dar-se-á habeas corpus sempre que alguém sofrer ou se achar na iminência de sofrer violência ou coação em sua liberdade de ir e vir, por ilegalidade ou abuso de poder.",
    keywords: ["habeas corpus", "hc", "liberdade", "coaçao", "ilegalidade"]
  },
  {
    code: "CPP",
    article: "648",
    title: "Hipóteses de HC",
    text: "A coação considerar-se-á ilegal: I - quando não houver justa causa; II - quando alguém estiver preso por mais tempo do que a lei permite; III - quando quem ordenar a coação não tiver competência para fazê-lo; IV - quando houver cessado o motivo que autorizou a coação; V - quando não for alguém admitido a prestar fiança; VI - quando o processo for manifestamente nulo; VII - quando extinta a punibilidade.",
    keywords: ["habeas corpus", "justa causa", "competencia", "nulidade", "extinçao punibilidade"]
  },
];

// Função de busca simples por palavras-chave
export function searchLocalLegal(query: string): LegalArticle[] {
  const normalized = query.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .trim();

  if (!normalized) return [];

  const terms = normalized.split(/\s+/).filter(t => t.length > 2);
  if (terms.length === 0) return [];

  return LEGAL_DATABASE.map(art => {
    const searchable = `${art.code} ${art.article} ${art.title || ""} ${art.text} ${art.note || ""} ${art.keywords.join(" ")}`
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const score = terms.reduce((acc, term) => acc + (searchable.includes(term) ? 1 : 0), 0);
    return { art, score };
  })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)
    .map(item => item.art);
}
