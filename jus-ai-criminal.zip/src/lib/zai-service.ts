// Serviços Z-AI — chat com GLM 5.2, web search e web reader
// Suporta 3 modos de configuração (em ordem de prioridade):
// 1. Variáveis de ambiente (ZAI_API_KEY + ZAI_BASE_URL) — recomendado para Vercel/produção
// 2. Arquivo .z-ai-config no projeto (escrito pela aba Config) — recomendado para dev local
// 3. Arquivo /etc/.z-ai-config (sandbox)
import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";
import path from "path";

let _zai: any = null;

/**
 * Verifica se as variáveis de ambiente ZAI_* estão configuradas.
 */
function hasEnvConfig(): boolean {
  return Boolean(process.env.ZAI_API_KEY);
}

/**
 * Cria instância ZAI com config apropriado.
 * Prioridade: env vars > .z-ai-config do projeto > /etc/.z-ai-config (sandbox)
 *
 * IMPORTANTE: O z-ai-web-dev-sdk só lê config de 3 lugares fixos:
 *   1. process.cwd()/.z-ai-config
 *   2. ~/.z-ai-config
 *   3. /etc/.z-ai-config
 *
 * Em serverless (Vercel), os 3 são read-only. Workaround: quando env vars existem,
 * escrevemos o config em /tmp/.z-ai-config e chdir temporariamente para /tmp.
 */
async function getZAI() {
  if (!_zai) {
    if (hasEnvConfig()) {
      // Modo env var — escreve config em /tmp (gravável em serverless)
      const tmpConfigPath = path.join("/tmp", ".z-ai-config");
      const config: any = {
        baseUrl: process.env.ZAI_BASE_URL || "https://api.z.ai/api/v1",
        apiKey: process.env.ZAI_API_KEY,
      };
      if (process.env.ZAI_USER_ID) config.userId = process.env.ZAI_USER_ID;
      try {
        fs.writeFileSync(tmpConfigPath, JSON.stringify(config), { mode: 0o600 });
        // Chdir temporário para /tmp — SDK procura process.cwd()/.z-ai-config
        const originalCwd = process.cwd();
        try {
          process.chdir("/tmp");
          _zai = await ZAI.create();
          process.chdir(originalCwd);
        } catch (err) {
          process.chdir(originalCwd);
          throw err;
        }
      } catch (err) {
        // Fallback: tenta criar direto (pode funcionar em alguns ambientes)
        _zai = await ZAI.create();
      }
    } else {
      _zai = await ZAI.create();
    }
  }
  return _zai;
}

/**
 * Exporta getter para uso em routes que precisam resetar/inicializar.
 */
export async function getZAIInstance() {
  return getZAI();
}

/**
 * Reseta o singleton ZAI — força recriação na próxima chamada.
 * Usar após mudança de config.
 */
export function resetZAI() {
  _zai = null;
}

/**
 * Caminho do arquivo de config no projeto (prioridade máxima no SDK).
 */
export const PROJECT_CONFIG_PATH = path.join(process.cwd(), ".z-ai-config");

/**
 * Lê o config ativo no projeto (se existir). Mascara a apiKey.
 */
export function readProjectConfig(): { exists: boolean; data?: any; masked?: any } {
  // Detecta modo env var primeiro
  if (hasEnvConfig()) {
    return {
      exists: true,
      data: null,
      masked: {
        baseUrl: process.env.ZAI_BASE_URL || "https://api.z.ai/api/v1",
        apiKey: process.env.ZAI_API_KEY
          ? `${process.env.ZAI_API_KEY.slice(0, 8)}••••••••${process.env.ZAI_API_KEY.slice(-4)}`
          : "",
        userId: process.env.ZAI_USER_ID || "",
        hasApiKey: Boolean(process.env.ZAI_API_KEY),
        source: "env-var",
      },
    };
  }

  try {
    if (!fs.existsSync(PROJECT_CONFIG_PATH)) {
      return { exists: false };
    }
    const raw = fs.readFileSync(PROJECT_CONFIG_PATH, "utf-8");
    const data = JSON.parse(raw);
    return {
      exists: true,
      data,
      masked: {
        baseUrl: data.baseUrl || "",
        apiKey: data.apiKey ? `${data.apiKey.slice(0, 8)}••••••••${data.apiKey.slice(-4)}` : "",
        userId: data.userId || "",
        hasApiKey: Boolean(data.apiKey),
        source: "project-file",
      },
    };
  } catch (err) {
    return { exists: false };
  }
}

/**
 * Retorna o modo de config ativo.
 */
export function getActiveConfigMode(): "env-var" | "project-file" | "system-fallback" {
  if (hasEnvConfig()) return "env-var";
  if (fs.existsSync(PROJECT_CONFIG_PATH)) return "project-file";
  return "system-fallback";
}

/**
 * Salva config no projeto (cria ou sobrescreve `.z-ai-config`).
 * Em serverless (Vercel), use variáveis de ambiente em vez desta função.
 */
export function writeProjectConfig(config: { baseUrl: string; apiKey: string; userId?: string }) {
  const payload: any = {
    baseUrl: config.baseUrl,
    apiKey: config.apiKey,
  };
  if (config.userId) payload.userId = config.userId;
  try {
    fs.writeFileSync(PROJECT_CONFIG_PATH, JSON.stringify(payload, null, 2), { mode: 0o600 });
  } catch (err: any) {
    // Se FS for read-only (Vercel), avisa o usuário para usar env vars
    if (err.code === "EROFS" || err.code === "EACCES") {
      throw new Error(
        "Filesystem read-only. Em produção (Vercel), configure as variáveis de ambiente ZAI_API_KEY e ZAI_BASE_URL no painel da Vercel."
      );
    }
    throw err;
  }
  resetZAI();
  return payload;
}

/**
 * Remove config do projeto — volta a usar /etc/.z-ai-config.
 */
export function deleteProjectConfig() {
  try {
    if (fs.existsSync(PROJECT_CONFIG_PATH)) {
      fs.unlinkSync(PROJECT_CONFIG_PATH);
    }
  } catch {}
  resetZAI();
}

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export interface ReaderResult {
  title: string;
  html: string;
  text: string;
  publishedTime?: string;
}

/**
 * Chat com GLM 5.2 — usa system prompt + mensagens do usuário
 */
export async function chatWithGLM(
  messages: ChatMessage[],
  options?: { temperature?: number; maxTokens?: number }
): Promise<string> {
  const zai = await getZAI();
  const response = await zai.chat.completions.create({
    messages,
    model: "glm-5.2",
    temperature: options?.temperature ?? 0.6,
    max_tokens: options?.maxTokens ?? 4096,
  });
  return response.choices[0]?.message?.content ?? "";
}

/**
 * Chat com streaming — para UX de digitação em tempo real
 * Retorna um async iterator de chunks de texto
 * 
 * NOTA: O stream do z-ai-web-dev-sdk GLM retorna Uint8Array contendo
 * texto SSE bruto (data: {...}\n\n). Precisamos decodificar e parsear manualmente.
 */
export async function* chatWithGLMStream(
  messages: ChatMessage[],
  options?: { temperature?: number; maxTokens?: number }
): AsyncGenerator<string> {
  const zai = await getZAI();
  const stream = await zai.chat.completions.create({
    messages,
    model: "glm-5.2",
    temperature: options?.temperature ?? 0.6,
    max_tokens: options?.maxTokens ?? 4096,
    stream: true,
  });

  let buffer = "";
  const decoder = new TextDecoder();

  for await (const rawChunk of stream) {
    // O chunk pode vir como Uint8Array (SSE bruto) ou como objeto parseado
    let chunkStr: string;
    if (rawChunk instanceof Uint8Array) {
      chunkStr = decoder.decode(rawChunk, { stream: true });
    } else if (typeof rawChunk === "string") {
      chunkStr = rawChunk;
    } else if (rawChunk && typeof rawChunk === "object") {
      // Tenta como objeto OpenAI-like
      const delta = (rawChunk as any)?.choices?.[0]?.delta?.content;
      if (delta) yield delta as string;
      continue;
    } else {
      continue;
    }

    buffer += chunkStr;
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith("data:")) continue;
      const payload = trimmed.slice(5).trim();
      if (payload === "[DONE]") return;
      try {
        const parsed = JSON.parse(payload);
        const delta = parsed?.choices?.[0]?.delta?.content;
        if (delta) yield delta as string;
      } catch {
        // ignore parse errors on partial lines
      }
    }
  }

  // Processa qualquer buffer restante
  if (buffer.trim().startsWith("data:")) {
    const payload = buffer.trim().slice(5).trim();
    if (payload && payload !== "[DONE]") {
      try {
        const parsed = JSON.parse(payload);
        const delta = parsed?.choices?.[0]?.delta?.content;
        if (delta) yield delta as string;
      } catch {}
    }
  }
}

/**
 * Web search via Z-AI — retorna resultados da web em tempo real
 */
export async function webSearch(query: string, num: number = 5): Promise<SearchResult[]> {
  try {
    const zai = await getZAI();
    const result = await zai.functions.invoke("web_search", {
      query,
      num,
    });
    if (Array.isArray(result)) {
      return result.map((r: any) => ({
        title: r.title || r.name || "",
        url: r.url || r.link || "",
        snippet: r.snippet || r.content || r.description || "",
      }));
    }
    return [];
  } catch (err) {
    console.error("webSearch error:", err);
    return [];
  }
}

/**
 * Web reader via Z-AI — extrai conteúdo de uma URL específica
 */
export async function webRead(url: string): Promise<ReaderResult | null> {
  try {
    const zai = await getZAI();
    const result = await zai.functions.invoke("web_reader", { url });
    return {
      title: result.title || "",
      html: result.html || "",
      text: result.text || result.content || "",
      publishedTime: result.publishedTime || result.publish_time,
    };
  } catch (err) {
    console.error("webRead error:", err);
    return null;
  }
}

/**
 * Detecta se a pergunta do usuário exige busca web (jurisprudência recente, lei alterada)
 */
export function shouldSearchWeb(userMessage: string): { shouldSearch: boolean; query: string } {
  const msg = userMessage.toLowerCase();
  const triggers = [
    "jurisprudência", "jurisprudencia", "stj", "stf", "precedente", "acórdão", "acordao",
    "recente", "atual", "lei alterada", "lei nova", "súmula", "sumula", "recurso repetitivo",
    "tema", "repercussão geral", "repercussao geral", "informativo", "decisão recente",
  ];
  const shouldSearch = triggers.some(t => msg.includes(t));
  if (shouldSearch) {
    // Constrói query de busca otimizada — adiciona "Brasil STJ STF" para filtrar
    const query = `${userMessage} Brasil STJ STF jurisprudência`;
    return { shouldSearch: true, query };
  }
  return { shouldSearch: false, query: "" };
}
