"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Gavel,
  Plus,
  Loader2,
  Copy,
  Trash2,
  Clock,
  Sparkles,
  Play,
  Pause,
  Square,
  FileText,
  Zap,
  MessageSquare,
  AlertTriangle,
  Eye,
  ChevronRight,
  RotateCcw,
  Lightbulb,
  ShieldAlert,
} from "lucide-react";
import {
  HEARING_TYPES,
  NOTE_CATEGORIES,
  QUESTION_TEMPLATES,
  COUNTER_ARGUMENTS,
  getHearingType,
} from "@/lib/hearing-catalog";

interface Note {
  id: string;
  category: string;
  witness: string;
  content: string;
  pageNumber?: string;
  timestamp: string;
}

interface HearingSession {
  id: string;
  type: string;
  caseTitle: string;
  caseFacts: string;
  defenseThesis: string;
  mpTheses: string[];
  notes: Note[];
  startedAt: string;
  status: "live" | "completed";
}

const STORAGE_KEY = "jusai_hearing_sessions";

export function AudienciaTab() {
  const [sessions, setSessions] = useState<HearingSession[]>([]);
  const [activeSession, setActiveSession] = useState<HearingSession | null>(null);
  const [view, setView] = useState<"list" | "setup" | "live" | "argument">("list");

  // Setup form
  const [setupType, setSetupType] = useState<string>("");
  const [setupCaseTitle, setSetupCaseTitle] = useState("");
  const [setupCaseFacts, setSetupCaseFacts] = useState("");
  const [setupDefenseThesis, setSetupDefenseThesis] = useState("");
  const [setupMpTheses, setSetupMpTheses] = useState<string[]>([]);

  // Live capture
  const [noteCategory, setNoteCategory] = useState<string>("depoimento");
  const [noteWitness, setNoteWitness] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [notePage, setNotePage] = useState("");
  const [mpTeseInput, setMpTeseInput] = useState("");
  const [showQuestionBank, setShowQuestionBank] = useState(false);
  const [timerRunning, setTimerRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generated argument
  const [generating, setGenerating] = useState(false);
  const [argument, setArgument] = useState<string>("");
  const [argumentSources, setArgumentSources] = useState<{ web: any[]; local: any[] }>({ web: [], local: [] });

  const { toast } = useToast();

  // Carrega sessões do localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) setSessions(JSON.parse(stored));
    } catch {}
  }, []);

  // Timer
  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => setElapsed(e => e + 1), 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerRunning]);

  // Persiste sessões
  function persist(newSessions: HearingSession[]) {
    setSessions(newSessions);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newSessions));
  }

  function updateActiveSession(updates: Partial<HearingSession>) {
    if (!activeSession) return;
    const updated = { ...activeSession, ...updates };
    setActiveSession(updated);
    const newSessions = sessions.map(s => (s.id === updated.id ? updated : s));
    persist(newSessions);
  }

  function startSession() {
    if (!setupType || !setupCaseTitle) {
      toast({ title: "Selecione o tipo e o título do caso", variant: "destructive" });
      return;
    }
    const newSession: HearingSession = {
      id: `sess-${Date.now()}`,
      type: setupType,
      caseTitle: setupCaseTitle,
      caseFacts: setupCaseFacts,
      defenseThesis: setupDefenseThesis,
      mpTheses: setupMpTheses,
      notes: [],
      startedAt: new Date().toISOString(),
      status: "live",
    };
    persist([newSession, ...sessions]);
    setActiveSession(newSession);
    setView("live");
    setElapsed(0);
    setTimerRunning(true);
    toast({ title: `Audiência iniciada · ${getHearingType(setupType)?.name}` });
  }

  function openSession(s: HearingSession) {
    setActiveSession(s);
    setView("live");
    setElapsed(0);
    setTimerRunning(false);
  }

  function deleteSession(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    if (!confirm("Excluir esta sessão de audiência?")) return;
    const newSessions = sessions.filter(s => s.id !== id);
    persist(newSessions);
    if (activeSession?.id === id) {
      setActiveSession(null);
      setView("list");
    }
  }

  function addNote() {
    if (!noteContent.trim()) {
      toast({ title: "Conteúdo da nota é obrigatório", variant: "destructive" });
      return;
    }
    const newNote: Note = {
      id: `note-${Date.now()}`,
      category: noteCategory,
      witness: noteWitness.trim(),
      content: noteContent.trim(),
      pageNumber: notePage.trim() || undefined,
      timestamp: new Date().toISOString(),
    };
    updateActiveSession({ notes: [...(activeSession?.notes || []), newNote] });
    setNoteContent("");
    setNotePage("");
    // mantém categoria e testemunha para notas sequenciais
  }

  function deleteNote(noteId: string) {
    if (!activeSession) return;
    updateActiveSession({ notes: activeSession.notes.filter(n => n.id !== noteId) });
  }

  function addMpTese() {
    if (!mpTeseInput.trim()) return;
    updateActiveSession({ mpTheses: [...(activeSession?.mpTheses || []), mpTeseInput.trim()] });
    setMpTeseInput("");
  }

  function removeMpTese(idx: number) {
    if (!activeSession) return;
    updateActiveSession({ mpTheses: activeSession.mpTheses.filter((_, i) => i !== idx) });
  }

  function applyQuestion(q: string) {
    setNoteCategory("pergunta");
    setNoteContent(q);
    setShowQuestionBank(false);
  }

  async function generateArgument() {
    if (!activeSession || activeSession.notes.length === 0) {
      toast({ title: "Adicione notas antes de gerar a sustentação", variant: "destructive" });
      return;
    }
    setGenerating(true);
    setArgument("");
    setView("argument");
    try {
      const res = await fetch("/api/oral-argument", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          hearingType: activeSession.type,
          caseTitle: activeSession.caseTitle,
          caseFacts: activeSession.caseFacts,
          notes: activeSession.notes,
          mpTheses: activeSession.mpTheses,
          defenseThesis: activeSession.defenseThesis,
          useSearch: true,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setArgument(data.argument);
      setArgumentSources(data.sources);
      toast({ title: "Sustentação oral gerada", description: `${data.notesCount} notas usadas` });
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  }

  function formatTime(seconds: number) {
    const h = Math.floor(seconds / 3600).toString().padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  }

  function copyArgument() {
    if (!argument) return;
    navigator.clipboard.writeText(argument);
    toast({ title: "Sustentação copiada" });
  }

  function getCategoryColor(catId: string) {
    const cat = NOTE_CATEGORIES.find(c => c.id === catId);
    if (!cat) return "border-border text-foreground";
    const map: Record<string, string> = {
      gold: "border-gold/40 text-gold bg-gold/5",
      forensic: "border-forensic/40 text-forensic bg-forensic/5",
      primary: "border-primary/40 text-primary bg-primary/5",
      destructive: "border-destructive/40 text-destructive bg-destructive/5",
      muted: "border-muted/40 text-muted-foreground bg-muted/5",
    };
    return map[cat.color] || "border-border text-foreground";
  }

  // === VIEW: LIST (lista de sessões) ===
  if (view === "list") {
    return (
      <div className="h-full">
        <Card className="flex flex-col h-full overflow-hidden p-0">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gavel className="h-4 w-4 text-gold" />
              <span className="text-sm font-semibold text-gold">Audiências</span>
            </div>
            <Button
              size="sm"
              onClick={() => setView("setup")}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              Nova audiência
            </Button>
          </div>

          <ScrollArea className="flex-1 scroll-thin">
            <div className="p-4">
              {sessions.length === 0 ? (
                <div className="text-center py-16 space-y-4">
                  <Gavel className="h-12 w-12 text-gold/30 mx-auto" />
                  <div className="space-y-1.5">
                    <h3 className="text-lg font-serif">Audiências criminais</h3>
                    <p className="text-sm text-muted-foreground max-w-md mx-auto">
                      Capture notas ao vivo durante a audiência. Rastreie contradições, perguntas e nulidades.
                      Gere sustentação oral final para contra-argumentar o MP.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-w-2xl mx-auto text-left">
                    {HEARING_TYPES.map(h => (
                      <Card key={h.id} className="p-3 border-gold/20 hover:border-gold/40 transition-colors">
                        <div className="text-sm font-semibold text-gold">{h.name}</div>
                        <div className="text-[10px] text-muted-foreground font-mono mt-0.5">{h.legalBasis}</div>
                        <div className="text-[11px] text-foreground/70 mt-1.5 line-clamp-2">{h.description}</div>
                        <div className="flex items-center gap-2 mt-2 text-[10px] text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          <span>{h.duration}</span>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {sessions.map(s => {
                    const h = getHearingType(s.type);
                    return (
                      <button
                        key={s.id}
                        onClick={() => openSession(s)}
                        className="group w-full text-left p-3 rounded-md border border-border hover:border-gold/40 transition-colors flex items-start justify-between gap-3"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-[9px] border-gold/40 text-gold">
                              {h?.name || s.type}
                            </Badge>
                            <Badge variant="outline" className="text-[9px] border-forensic/30 text-forensic">
                              {s.notes.length} notas
                            </Badge>
                            {s.mpTheses.length > 0 && (
                              <Badge variant="outline" className="text-[9px] border-destructive/30 text-destructive">
                                {s.mpTheses.length} teses MP
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm font-medium text-foreground truncate">{s.caseTitle}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">
                            Início: {new Date(s.startedAt).toLocaleString("pt-BR")}
                          </div>
                          {s.defenseThesis && (
                            <div className="text-[11px] text-gold/70 mt-1 italic line-clamp-1">
                              Tese: {s.defenseThesis}
                            </div>
                          )}
                        </div>
                        <Trash2
                          onClick={e => deleteSession(s.id, e)}
                          className="h-3 w-3 opacity-0 group-hover:opacity-60 hover:opacity-100 text-forensic shrink-0 mt-1"
                        />
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </ScrollArea>
        </Card>
      </div>
    );
  }

  // === VIEW: SETUP (configuração antes da audiência) ===
  if (view === "setup") {
    return (
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setView("list")} className="text-xs">
              ← Voltar
            </Button>
            <span className="text-sm font-semibold text-gold">Nova Audiência</span>
          </div>
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4 space-y-4 max-w-2xl">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">Tipo de audiência *</Label>
              <Select value={setupType} onValueChange={setSetupType}>
                <SelectTrigger className="bg-background border-border focus:ring-gold">
                  <SelectValue placeholder="Selecione o tipo..." />
                </SelectTrigger>
                <SelectContent>
                  {HEARING_TYPES.map(h => (
                    <SelectItem key={h.id} value={h.id}>
                      <div className="flex flex-col">
                        <span className="text-sm">{h.name}</span>
                        <span className="text-[10px] text-muted-foreground">{h.legalBasis}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {setupType && (() => {
              const h = getHearingType(setupType);
              if (!h) return null;
              return (
                <Card className="p-3 border-gold/20 bg-gold/5 space-y-2">
                  <div className="text-sm font-semibold text-gold">{h.name}</div>
                  <div className="text-[10px] text-muted-foreground font-mono">{h.legalBasis} · {h.duration}</div>
                  <p className="text-xs text-foreground/80">{h.description}</p>
                  <div className="text-[11px] text-muted-foreground">
                    <strong className="text-gold">Participantes:</strong> {h.participants.join(", ")}
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    <strong className="text-gold">Objetivo:</strong> {h.goal}
                  </div>
                  <div className="border-t border-gold/20 pt-2 mt-2">
                    <div className="text-[10px] uppercase tracking-widest text-forensic font-semibold mb-1.5 flex items-center gap-1">
                      <Lightbulb className="h-3 w-3" /> Dicas estratégicas
                    </div>
                    <ul className="space-y-1">
                      {h.keyTips.map((tip, i) => (
                        <li key={i} className="text-[11px] text-foreground/80 flex items-start gap-1.5">
                          <span className="text-forensic mt-0.5">▸</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              );
            })()}

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">Título do caso *</Label>
              <Input
                value={setupCaseTitle}
                onChange={e => setSetupCaseTitle(e.target.value)}
                placeholder="Ex: João da Silva — HC 0001234-56.2026.4.01.3400"
                className="bg-background border-border focus-visible:ring-gold text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">Resumo dos fatos</Label>
              <Textarea
                value={setupCaseFacts}
                onChange={e => setSetupCaseFacts(e.target.value)}
                placeholder="Descreva os fatos do caso que será discutido na audiência..."
                className="bg-background border-border focus-visible:ring-gold text-sm min-h-[80px]"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">Tese central da defesa</Label>
              <Textarea
                value={setupDefenseThesis}
                onChange={e => setSetupDefenseThesis(e.target.value)}
                placeholder="Ex: Legítima defesa · Negativa de autoria · Atipicidade · Cadeia de custódia violada..."
                className="bg-background border-border focus-visible:ring-gold text-sm min-h-[60px]"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80 flex items-center gap-1">
                <ShieldAlert className="h-3 w-3 text-forensic" />
                Teses do MP (para refutar depois)
              </Label>
              <div className="flex gap-2">
                <Input
                  value={mpTeseInput}
                  onChange={e => setMpTeseInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addMpTese(); } }}
                  placeholder="Ex: Materialidade comprovada pelo laudo"
                  className="bg-background border-border focus-visible:ring-gold text-sm"
                />
                <Button onClick={addMpTese} variant="outline" className="border-forensic/40 text-forensic hover:bg-forensic/10">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {setupMpTheses.length > 0 && (
                <div className="space-y-1 mt-2">
                  {setupMpTheses.map((t, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className="text-forensic">▸</span>
                      <span className="flex-1 text-foreground/80">{t}</span>
                      <button onClick={() => setSetupMpTheses(setupMpTheses.filter((_, idx) => idx !== i))}>
                        <Trash2 className="h-3 w-3 text-forensic/60 hover:text-forensic" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="text-[10px] text-muted-foreground mt-1">
                💡 Sugestões: {COUNTER_ARGUMENTS.slice(0, 4).map(c => c.mpTese).join(" · ")}...
              </div>
            </div>

            <Button onClick={startSession} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              <Play className="h-4 w-4 mr-2" />
              Iniciar audiência e captura
            </Button>
          </div>
        </ScrollArea>
      </Card>
    );
  }

  // === VIEW: LIVE (captura ao vivo durante audiência) ===
  if (view === "live" && activeSession) {
    const hearing = getHearingType(activeSession.type);
    return (
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-4 h-full">
        {/* Coluna principal — captura de notas */}
        <Card className="flex flex-col h-full overflow-hidden p-0">
          <div className="p-3 border-b border-border">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => setView("list")} className="text-xs h-7">
                  ← Sair
                </Button>
                <span className="text-sm font-semibold text-gold">{hearing?.name}</span>
                <Badge variant="outline" className="text-[9px] border-forensic/40 text-forensic">
                  ● AO VIVO
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <div className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs font-mono ${timerRunning ? "text-forensic bg-forensic/10" : "text-muted-foreground bg-muted"}`}>
                  <Clock className="h-3 w-3" />
                  {formatTime(elapsed)}
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setTimerRunning(!timerRunning)}
                  className="h-7 w-7 p-0"
                >
                  {timerRunning ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => { setElapsed(0); setTimerRunning(false); }}
                  className="h-7 w-7 p-0"
                >
                  <RotateCcw className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="text-xs text-foreground/80 truncate">{activeSession.caseTitle}</div>
          </div>

          {/* Quick note capture */}
          <div className="p-3 border-b border-border space-y-2">
            <div className="flex flex-wrap gap-1.5">
              {NOTE_CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setNoteCategory(cat.id)}
                  className={`text-[10px] px-2 py-1 rounded border transition-all ${
                    noteCategory === cat.id
                      ? getCategoryColor(cat.id) + " font-semibold"
                      : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                  title={cat.hint}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Input
                value={noteWitness}
                onChange={e => setNoteWitness(e.target.value)}
                placeholder="Testemunha (nome)"
                className="bg-background border-border focus-visible:ring-gold text-sm h-8"
              />
              <Input
                value={notePage}
                onChange={e => setNotePage(e.target.value)}
                placeholder="Página autos (ex: 45)"
                className="bg-background border-border focus-visible:ring-gold text-sm h-8"
              />
              <Button onClick={addNote} className="bg-primary hover:bg-primary/90 text-primary-foreground h-8">
                <Plus className="h-3 w-3 mr-1" /> Add
              </Button>
            </div>

            <Textarea
              value={noteContent}
              onChange={e => setNoteContent(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); addNote(); } }}
              placeholder={`Anotar ${NOTE_CATEGORIES.find(c => c.id === noteCategory)?.label.toLowerCase()}... (Ctrl+Enter para adicionar)`}
              className="bg-background border-border focus-visible:ring-gold text-sm min-h-[60px]"
            />

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowQuestionBank(true)}
                className="text-[11px] border-gold/40 text-gold hover:bg-gold/10"
              >
                <MessageSquare className="h-3 w-3 mr-1.5" />
                Banco de perguntas
              </Button>
            </div>
          </div>

          {/* Lista de notas */}
          <ScrollArea className="flex-1 scroll-thin">
            <div className="p-3 space-y-2">
              {activeSession.notes.length === 0 ? (
                <div className="text-center py-12 text-xs text-muted-foreground">
                  <Eye className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  Comece a capturar notas acima. Use categorias para organizar.
                </div>
              ) : (
                [...activeSession.notes].reverse().map(note => {
                  const cat = NOTE_CATEGORIES.find(c => c.id === note.category);
                  return (
                    <Card key={note.id} className={`p-2.5 ${getCategoryColor(note.category)}`}>
                      <div className="flex items-start gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px]">{cat?.icon}</span>
                            <span className="text-[10px] uppercase tracking-widest font-semibold">
                              {cat?.label}
                            </span>
                            {note.witness && (
                              <span className="text-[10px] text-foreground/60">· {note.witness}</span>
                            )}
                            {note.pageNumber && (
                              <span className="text-[10px] font-mono text-foreground/60">· p.{note.pageNumber}</span>
                            )}
                            <span className="text-[10px] text-muted-foreground ml-auto">
                              {new Date(note.timestamp).toLocaleTimeString("pt-BR")}
                            </span>
                          </div>
                          <p className="text-xs text-foreground/90 leading-relaxed">{note.content}</p>
                        </div>
                        <button onClick={() => deleteNote(note.id)}>
                          <Trash2 className="h-3 w-3 text-forensic/60 hover:text-forensic shrink-0" />
                        </button>
                      </div>
                    </Card>
                  );
                })
              )}
            </div>
          </ScrollArea>

          {/* Botão gerar sustentação */}
          {activeSession.notes.length > 0 && (
            <div className="p-3 border-t border-border">
              <Button
                onClick={generateArgument}
                disabled={generating}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {generating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Construindo sustentação...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Gerar sustentação oral final ({activeSession.notes.length} notas)
                  </>
                )}
              </Button>
            </div>
          )}
        </Card>

        {/* Lateral — info da audiência + teses do MP */}
        <Card className="flex flex-col h-full overflow-hidden p-0">
          <ScrollArea className="flex-1 scroll-thin">
            <div className="p-3 space-y-3">
              {hearing && (
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-gold font-semibold mb-1.5">
                    Objetivo
                  </div>
                  <p className="text-xs text-foreground/80">{hearing.goal}</p>
                </div>
              )}

              {hearing && hearing.keyTips.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-forensic font-semibold mb-1.5 flex items-center gap-1">
                    <Lightbulb className="h-3 w-3" /> Dicas
                  </div>
                  <ul className="space-y-1">
                    {hearing.keyTips.slice(0, 5).map((tip, i) => (
                      <li key={i} className="text-[11px] text-foreground/80 flex items-start gap-1.5">
                        <span className="text-forensic mt-0.5">▸</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="border-t border-border pt-3">
                <div className="text-[10px] uppercase tracking-widest text-destructive font-semibold mb-1.5 flex items-center gap-1">
                  <ShieldAlert className="h-3 w-3" /> Teses do MP ({activeSession.mpTheses.length})
                </div>
                {activeSession.mpTheses.length === 0 ? (
                  <p className="text-[11px] text-muted-foreground italic">
                    Nenhuma tese do MP registrada. Adicione ao ouvir o promotor.
                  </p>
                ) : (
                  <ul className="space-y-1.5">
                    {activeSession.mpTheses.map((t, i) => (
                      <li key={i} className="text-[11px] text-foreground/80 flex items-start gap-1.5">
                        <span className="text-destructive mt-0.5">⚡</span>
                        <span className="flex-1">{t}</span>
                        <button onClick={() => removeMpTese(i)}>
                          <Trash2 className="h-3 w-3 text-destructive/60 hover:text-destructive" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="flex gap-2 mt-2">
                  <Input
                    value={mpTeseInput}
                    onChange={e => setMpTeseInput(e.target.value)}
                    onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addMpTese(); } }}
                    placeholder="Nova tese do MP..."
                    className="bg-background border-border focus-visible:ring-gold text-xs h-7"
                  />
                  <Button onClick={addMpTese} size="sm" variant="outline" className="h-7 px-2 border-destructive/40 text-destructive">
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div className="border-t border-border pt-3">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
                  Estatísticas
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-lg font-mono text-gold">{activeSession.notes.length}</div>
                    <div className="text-[10px] text-muted-foreground">Notas</div>
                  </div>
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-lg font-mono text-forensic">
                      {activeSession.notes.filter(n => n.category === "contradicao").length}
                    </div>
                    <div className="text-[10px] text-muted-foreground">Contradições</div>
                  </div>
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-lg font-mono text-destructive">
                      {activeSession.notes.filter(n => n.category === "nulidade").length}
                    </div>
                    <div className="text-[10px] text-muted-foreground">Nulidades</div>
                  </div>
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-lg font-mono text-primary">
                      {activeSession.notes.filter(n => n.category === "pergunta").length}
                    </div>
                    <div className="text-[10px] text-muted-foreground">Perguntas</div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        </Card>

        {/* Dialog: Banco de perguntas */}
        <Dialog open={showQuestionBank} onOpenChange={setShowQuestionBank}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle className="text-gold flex items-center gap-2">
                <MessageSquare className="h-4 w-4" /> Banco de Perguntas
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="flex-1 scroll-thin -mx-6 px-6">
              <div className="space-y-4">
                {QUESTION_TEMPLATES.map(group => (
                  <div key={group.category}>
                    <div className="text-[10px] uppercase tracking-widest text-gold font-semibold mb-2">
                      {group.label}
                    </div>
                    <div className="space-y-1">
                      {group.questions.map((q, i) => (
                        <button
                          key={i}
                          onClick={() => applyQuestion(q)}
                          className="w-full text-left p-2 rounded border border-border hover:border-gold/40 hover:bg-gold/5 transition-colors text-xs text-foreground/80"
                        >
                          <div className="flex items-center gap-2">
                            <ChevronRight className="h-3 w-3 text-gold shrink-0" />
                            <span>{q}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // === VIEW: ARGUMENT (sustentação oral gerada) ===
  if (view === "argument" && activeSession) {
    return (
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setView("live")} className="text-xs">
              ← Voltar às notas
            </Button>
            <span className="text-sm font-semibold text-gold">Sustentação Oral</span>
          </div>
          {argument && (
            <Button size="sm" variant="ghost" onClick={copyArgument} className="text-xs hover:text-gold">
              <Copy className="h-3 w-3 mr-1" /> Copiar
            </Button>
          )}
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4">
            {generating && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <Loader2 className="h-10 w-10 text-gold animate-spin" />
                <div className="space-y-1">
                  <div className="text-sm text-gold">Construindo sustentação oral...</div>
                  <div className="text-xs text-muted-foreground max-w-md">
                    Aplicando: refutação das teses do MP · análise de prova · contradições · tese · pedido
                  </div>
                </div>
              </div>
            )}

            {!generating && !argument && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <FileText className="h-12 w-12 text-gold/30" />
                <p className="text-sm text-muted-foreground max-w-md">
                  Gere a sustentação oral a partir das {activeSession.notes.length} notas capturadas.
                </p>
                <Button onClick={generateArgument} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Sparkles className="h-4 w-4 mr-2" /> Gerar agora
                </Button>
              </div>
            )}

            {argument && (
              <div className="space-y-4">
                <Card className="p-3 border-gold/20 bg-gold/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-gold">{getHearingType(activeSession.type)?.name}</div>
                      <div className="text-[10px] text-muted-foreground">{activeSession.caseTitle}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest">Tempo estimado</div>
                      <div className="text-sm font-mono text-forensic">~15-20 min</div>
                    </div>
                  </div>
                </Card>

                <div className="font-mono text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">
                  {argument}
                </div>

                {(argumentSources.local?.length > 0 || argumentSources.web?.length > 0) && (
                  <div className="border-t border-border pt-3 space-y-2">
                    <div className="text-[10px] uppercase tracking-widest text-gold font-semibold">
                      Fontes consultadas
                    </div>
                    {argumentSources.local?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {argumentSources.local.map((art: any, i: number) => (
                          <Badge key={i} variant="outline" className="text-[10px] border-gold/30 text-gold">
                            {art.code} art. {art.article}
                          </Badge>
                        ))}
                      </div>
                    )}
                    {argumentSources.web?.length > 0 && (
                      <div className="space-y-1">
                        {argumentSources.web.map((src: any, i: number) => (
                          <a
                            key={i}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block text-[11px] text-forensic hover:underline"
                          >
                            [{i + 1}] {src.title}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </ScrollArea>
      </Card>
    );
  }

  return null;
}
