"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Search, Loader2, ExternalLink, FileText, BookOpen, Scale } from "lucide-react";

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

interface LocalResult {
  code: string;
  article: string;
  title?: string;
  text: string;
  note?: string;
  keywords: string[];
}

export function SearchTab() {
  const [query, setQuery] = useState("");
  const [webResults, setWebResults] = useState<SearchResult[]>([]);
  const [localResults, setLocalResults] = useState<LocalResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeSource, setActiveSource] = useState<"all" | "web" | "local">("all");
  const { toast } = useToast();

  async function search() {
    if (!query.trim()) return;
    setLoading(true);
    setWebResults([]);
    setLocalResults([]);

    try {
      const [webRes, localRes] = await Promise.all([
        fetch("/api/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query, num: 8 }),
        }),
        fetch("/api/legal-search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query }),
        }),
      ]);

      const webData = await webRes.json();
      const localData = await localRes.json();
      setWebResults(webData.results || []);
      setLocalResults(localData.results || []);

      toast({
        title: `Busca concluída`,
        description: `${(webData.results || []).length} resultados web · ${localData.results?.length || 0} da base local`,
      });
    } catch (err: any) {
      toast({ title: "Erro na busca: " + err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") search();
  }

  const filteredWeb = activeSource === "local" ? [] : webResults;
  const filteredLocal = activeSource === "web" ? [] : localResults;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4 h-full">
      {/* Coluna principal — resultados */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-4 border-b border-border">
          <div className="flex gap-2">
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Buscar: jurisprudência STJ STF · artigos CP/CPP · tema jurídico..."
              className="bg-background border-border focus-visible:ring-gold text-sm"
            />
            <Button
              onClick={search}
              disabled={!query.trim() || loading}
              className="bg-primary hover:bg-primary/90 text-primary-foreground shrink-0"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>
          <div className="flex gap-2 mt-2">
            <button
              onClick={() => setActiveSource("all")}
              className={`text-[11px] px-2.5 py-1 rounded-md border transition-colors ${
                activeSource === "all" ? "border-gold text-gold bg-gold/10" : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              Todas as fontes
            </button>
            <button
              onClick={() => setActiveSource("web")}
              className={`text-[11px] px-2.5 py-1 rounded-md border transition-colors ${
                activeSource === "web" ? "border-forensic text-forensic bg-forensic/10" : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              Web (tempo real)
            </button>
            <button
              onClick={() => setActiveSource("local")}
              className={`text-[11px] px-2.5 py-1 rounded-md border transition-colors ${
                activeSource === "local" ? "border-gold text-gold bg-gold/10" : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              Base local CP/CPP
            </button>
          </div>
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4 space-y-4">
            {/* Resultados base local */}
            {filteredLocal.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-gold font-semibold">
                  <BookOpen className="h-3.5 w-3.5" /> Base local — CP/CPP/CF
                </div>
                {filteredLocal.map((art, i) => (
                  <Card key={i} className="p-3 border-gold/20 bg-gold/5">
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="border-gold/40 text-gold text-[10px] shrink-0">
                        {art.code} art. {art.article}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        {art.title && (
                          <div className="text-xs font-semibold text-gold mb-1">{art.title}</div>
                        )}
                        <p className="text-sm text-foreground/90 leading-relaxed">{art.text}</p>
                        {art.note && (
                          <p className="text-xs text-muted-foreground italic mt-2">↳ {art.note}</p>
                        )}
                        <div className="flex flex-wrap gap-1 mt-2">
                          {art.keywords.slice(0, 4).map((kw, idx) => (
                            <span key={idx} className="text-[10px] text-muted-foreground/70 px-1.5 py-0.5 rounded bg-muted">
                              {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Resultados web */}
            {filteredWeb.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-forensic font-semibold">
                  <Search className="h-3.5 w-3.5" /> Web — busca em tempo real
                </div>
                {filteredWeb.map((res, i) => (
                  <Card key={i} className="p-3 border-border hover:border-forensic/30 transition-colors">
                    <a
                      href={res.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block space-y-1"
                    >
                      <div className="flex items-start gap-2">
                        <ExternalLink className="h-3 w-3 mt-1 text-forensic/60 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-foreground hover:text-forensic transition-colors">
                            {res.title || "(sem título)"}
                          </div>
                          <div className="text-[10px] text-muted-foreground truncate">
                            {res.url}
                          </div>
                          <p className="text-xs text-foreground/70 mt-1.5 leading-relaxed line-clamp-3">
                            {res.snippet}
                          </p>
                        </div>
                      </div>
                    </a>
                  </Card>
                ))}
              </div>
            )}

            {/* Empty state */}
            {!loading && webResults.length === 0 && localResults.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <Scale className="h-12 w-12 text-gold/30" />
                <div className="space-y-1.5">
                  <h3 className="text-lg font-serif">Busca jurídica unificada</h3>
                  <p className="text-sm text-muted-foreground max-w-md">
                    Pesquise simultaneamente na web (JusBrasil, STJ, STF, Planalto) e na base local de artigos do CP, CPP e CF.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2 justify-center">
                  {[
                    "legítima defesa CP art. 25",
                    "habeas corpus CPP 647",
                    "cadeia de custódia Lei 13.964",
                    "tribunal do júri CF 5º XXXVIII",
                    "acordo de não perseguição CPP 28-A",
                  ].map(sug => (
                    <button
                      key={sug}
                      onClick={() => setQuery(sug)}
                      className="text-[11px] px-3 py-1.5 rounded-md border border-border hover:border-gold hover:text-gold transition-colors"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </Card>

      {/* Lateral — info / reader */}
      <Card className="p-4 space-y-3 h-full overflow-hidden flex flex-col">
        <div className="text-xs uppercase tracking-widest text-gold font-semibold flex items-center gap-2">
          <FileText className="h-3.5 w-3.5" /> Fontes disponíveis
        </div>
        <div className="space-y-2 text-xs text-foreground/70">
          <div className="flex items-start gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-gold mt-1.5 shrink-0"></div>
            <div>
              <strong className="text-gold">Web search (tempo real)</strong>
              <p className="text-muted-foreground mt-0.5">JusBrasil, STJ, STF, Planalto, TJs</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-forensic mt-1.5 shrink-0"></div>
            <div>
              <strong className="text-forensic">Web reader (URL)</strong>
              <p className="text-muted-foreground mt-0.5">Extrai texto de páginas específicas</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-gold mt-1.5 shrink-0"></div>
            <div>
              <strong className="text-gold">Base local CP/CPP/CF</strong>
              <p className="text-muted-foreground mt-0.5">Curadoria dos artigos essenciais — offline</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-gold mt-1.5 shrink-0"></div>
            <div>
              <strong className="text-gold">Memória local (Prisma)</strong>
              <p className="text-muted-foreground mt-0.5">Conversas e peças salvas pelo usuário</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-3 mt-auto">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
            Estatísticas
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-muted/50 rounded p-2">
              <div className="text-lg font-mono text-gold">{webResults.length}</div>
              <div className="text-[10px] text-muted-foreground">Web</div>
            </div>
            <div className="bg-muted/50 rounded p-2">
              <div className="text-lg font-mono text-gold">{localResults.length}</div>
              <div className="text-[10px] text-muted-foreground">Local</div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
