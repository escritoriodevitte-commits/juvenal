"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import {
  Target,
  Loader2,
  Copy,
  Save,
  Scale,
  Search,
  Sparkles,
  Shield,
} from "lucide-react";

export function StrategyTab() {
  const [caseDescription, setCaseDescription] = useState("");
  const [crime, setCrime] = useState("");
  const [clientGoals, setClientGoals] = useState("");
  const [additionalContext, setAdditionalContext] = useState("");
  const [useSearch, setUseSearch] = useState(true);

  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<{
    strategy: string;
    sources: { web: any[]; local: any[] };
  } | null>(null);

  const { toast } = useToast();

  async function generate() {
    if (!caseDescription) {
      toast({ title: "Descrição do caso é obrigatória", variant: "destructive" });
      return;
    }
    setGenerating(true);
    setResult(null);

    try {
      const res = await fetch("/api/strategy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caseDescription,
          crime,
          clientGoals,
          additionalContext,
          useSearch,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setResult(data);
      toast({ title: "Estratégia gerada com sucesso" });
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  }

  function copyStrategy() {
    if (!result?.strategy) return;
    navigator.clipboard.writeText(result.strategy);
    toast({ title: "Estratégia copiada" });
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[400px_1fr] gap-4 h-full">
      {/* Formulário */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2 text-sm font-semibold text-gold">
            <Target className="h-4 w-4" />
            Estratégia Defensiva
          </div>
          <p className="text-[11px] text-muted-foreground mt-1">
            Metodologia de 4 blocos: Fatos · Direito · Prova · Narrativa
          </p>
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4 space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">
                Tipificação alegada
              </Label>
              <Input
                value={crime}
                onChange={e => setCrime(e.target.value)}
                placeholder="Ex: art. 121 CP (homicídio), art. 33 Lei 11.343 (tráfico)..."
                className="bg-background border-border focus-visible:ring-gold text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">
                Descrição do caso *
              </Label>
              <Textarea
                value={caseDescription}
                onChange={e => setCaseDescription(e.target.value)}
                placeholder="Narrativa do caso: o que aconteceu, quem é o acusado, qual a versão policial, quais as provas existentes, situação processual atual..."
                className="resize-none min-h-[160px] bg-background border-border focus-visible:ring-gold text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">
                Objetivos do cliente
              </Label>
              <Textarea
                value={clientGoals}
                onChange={e => setClientGoals(e.target.value)}
                placeholder="Absolvição · redução de pena · liberdade provisória · acordo de não perseguição · desclassificação..."
                className="resize-none min-h-[80px] bg-background border-border focus-visible:ring-gold text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80">
                Contexto adicional
              </Label>
              <Textarea
                value={additionalContext}
                onChange={e => setAdditionalContext(e.target.value)}
                placeholder="Informações extras: antecedentes, situação financeira, testemunhas conhecidas,等等..."
                className="resize-none min-h-[60px] bg-background border-border focus-visible:ring-gold text-sm"
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer text-xs text-foreground/80">
              <input
                type="checkbox"
                checked={useSearch}
                onChange={e => setUseSearch(e.target.checked)}
                className="accent-gold"
              />
              <Search className="h-3 w-3 text-gold" />
              Buscar jurisprudência atualizada
            </label>
          </div>
        </ScrollArea>

        <div className="p-3 border-t border-border">
          <Button
            onClick={generate}
            disabled={!caseDescription || generating}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Construindo estratégia...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Gerar estratégia defensiva
              </>
            )}
          </Button>
        </div>
      </Card>

      {/* Resultado */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-forensic" />
            <span className="text-sm font-semibold text-gold">
              {result ? "Estratégia Defensiva" : "Análise estratégica"}
            </span>
          </div>
          {result && (
            <Button size="sm" variant="ghost" onClick={copyStrategy} className="h-7 text-xs hover:text-gold">
              <Copy className="h-3 w-3 mr-1" /> Copiar
            </Button>
          )}
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4">
            {generating && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <Loader2 className="h-10 w-10 text-gold animate-spin" />
                <div className="space-y-1">
                  <div className="text-sm text-gold">Construindo estratégia...</div>
                  <div className="text-xs text-muted-foreground max-w-md">
                    Aplicando metodologia: Fatos · Direito · Prova · Narrativa + tese recomendada + peças + riscos + bibliografia
                  </div>
                </div>
              </div>
            )}

            {!generating && !result && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <Target className="h-12 w-12 text-gold/30" />
                <div className="space-y-1.5">
                  <h3 className="text-lg font-serif">Estratégia defensiva em 4 blocos</h3>
                  <p className="text-sm text-muted-foreground max-w-md">
                    O agente constrói teoria do caso defensiva com: análise fática, tipificação e excludentes, mapa probatório e construção narrativa.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2 max-w-md text-left">
                  {[
                    { n: "01", t: "FATOS", d: "Releitura crítica do inquérito" },
                    { n: "02", t: "DIREITO", d: "Tipificação e excludentes" },
                    { n: "03", t: "PROVA", d: "Mapa probatório e nulidades" },
                    { n: "04", t: "NARRATIVA", d: "Construção da tese defensiva" },
                  ].map(b => (
                    <Card key={b.n} className="p-2 border-gold/20">
                      <div className="text-[10px] font-mono text-gold">{b.n}</div>
                      <div className="text-xs font-semibold text-foreground">{b.t}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">{b.d}</div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {result && (
              <div className="space-y-4">
                <div className="font-mono text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">
                  {result.strategy}
                </div>

                {result.sources && (result.sources.local?.length > 0 || result.sources.web?.length > 0) && (
                  <div className="border-t border-border pt-4 space-y-3">
                    <div className="text-[10px] uppercase tracking-widest text-gold font-semibold">
                      Fontes consultadas
                    </div>
                    {result.sources.local?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {result.sources.local.map((art: any, i: number) => (
                          <Badge key={i} variant="outline" className="text-[10px] border-gold/30 text-gold">
                            {art.code} art. {art.article}
                          </Badge>
                        ))}
                      </div>
                    )}
                    {result.sources.web?.length > 0 && (
                      <div className="space-y-1">
                        {result.sources.web.map((src: any, i: number) => (
                          <a
                            key={i}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block text-[11px] text-forensic hover:underline"
                          >
                            [{i + 1}] {src.title}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
}
