"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  FolderKanban,
  Plus,
  Loader2,
  Trash2,
  FileText,
  ChevronRight,
  Folder,
} from "lucide-react";

interface CaseItem {
  id: string;
  title: string;
  clientName?: string;
  caseNumber?: string;
  crime?: string;
  summary?: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  _count?: { pieces: number; notes: number };
  pieces?: PieceItem[];
}

interface PieceItem {
  id: string;
  title: string;
  pieceType: string;
  content: string;
  updatedAt: string;
}

export function CasesTab() {
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [activeCase, setActiveCase] = useState<CaseItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [newCase, setNewCase] = useState({
    title: "",
    clientName: "",
    caseNumber: "",
    crime: "",
    summary: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    loadCases();
  }, []);

  async function loadCases() {
    setLoading(true);
    try {
      const res = await fetch("/api/cases");
      const data = await res.json();
      setCases(data.cases || []);
    } catch {
      toast({ title: "Erro ao carregar casos", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function createCase() {
    if (!newCase.title) {
      toast({ title: "Título é obrigatório", variant: "destructive" });
      return;
    }
    try {
      const res = await fetch("/api/cases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCase),
      });
      const data = await res.json();
      setCases([data.case, ...cases]);
      setNewCase({ title: "", clientName: "", caseNumber: "", crime: "", summary: "" });
      setCreateOpen(false);
      toast({ title: "Caso criado" });
    } catch {
      toast({ title: "Erro ao criar caso", variant: "destructive" });
    }
  }

  async function selectCase(c: CaseItem) {
    try {
      const res = await fetch(`/api/cases/${c.id}`);
      const data = await res.json();
      setActiveCase(data.case);
    } catch {
      toast({ title: "Erro ao abrir caso", variant: "destructive" });
    }
  }

  async function deleteCase(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    try {
      await fetch(`/api/cases/${id}`, { method: "DELETE" });
      setCases(cases.filter(c => c.id !== id));
      if (activeCase?.id === id) setActiveCase(null);
      toast({ title: "Caso excluído" });
    } catch {
      toast({ title: "Erro ao excluir", variant: "destructive" });
    }
  }

  const statusColor: Record<string, string> = {
    ativo: "border-gold/40 text-gold",
    arquivado: "border-border text-muted-foreground",
    concluido: "border-forensic/40 text-forensic",
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.5fr] gap-4 h-full">
      {/* Lista de casos */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderKanban className="h-4 w-4 text-gold" />
            <span className="text-sm font-semibold text-gold">Casos</span>
          </div>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0 hover:text-gold">
                <Plus className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle className="text-gold">Novo caso</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label className="text-xs uppercase tracking-widest text-gold/80">Título *</Label>
                  <Input
                    value={newCase.title}
                    onChange={e => setNewCase({ ...newCase, title: e.target.value })}
                    placeholder="Ex: HC — João da Silva"
                    className="bg-background border-border focus-visible:ring-gold mt-1"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs uppercase tracking-widest text-gold/80">Cliente</Label>
                    <Input
                      value={newCase.clientName}
                      onChange={e => setNewCase({ ...newCase, clientName: e.target.value })}
                      className="bg-background border-border focus-visible:ring-gold mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs uppercase tracking-widest text-gold/80">Crime</Label>
                    <Input
                      value={newCase.crime}
                      onChange={e => setNewCase({ ...newCase, crime: e.target.value })}
                      placeholder="art. 121 CP"
                      className="bg-background border-border focus-visible:ring-gold mt-1"
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-xs uppercase tracking-widest text-gold/80">Nº processo</Label>
                  <Input
                    value={newCase.caseNumber}
                    onChange={e => setNewCase({ ...newCase, caseNumber: e.target.value })}
                    placeholder="0000000-00.0000.0.00.0000"
                    className="bg-background border-border focus-visible:ring-gold mt-1 font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs uppercase tracking-widest text-gold/80">Resumo</Label>
                  <Textarea
                    value={newCase.summary}
                    onChange={e => setNewCase({ ...newCase, summary: e.target.value })}
                    className="bg-background border-border focus-visible:ring-gold mt-1 min-h-[80px]"
                  />
                </div>
                <Button onClick={createCase} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  Criar caso
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-2 space-y-1">
            {loading ? (
              <div className="p-4 text-center text-xs text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
              </div>
            ) : cases.length === 0 ? (
              <div className="p-6 text-center text-xs text-muted-foreground">
                <Folder className="h-8 w-8 mx-auto mb-2 opacity-30" />
                Nenhum caso. Clique em + para criar.
              </div>
            ) : (
              cases.map(c => (
                <button
                  key={c.id}
                  onClick={() => selectCase(c)}
                  className={`group w-full text-left p-3 rounded-md hover:bg-sidebar-accent transition-colors ${
                    activeCase?.id === c.id ? "bg-sidebar-accent border-l-2 border-gold" : ""
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">{c.title}</div>
                      {c.clientName && (
                        <div className="text-[11px] text-muted-foreground mt-0.5">{c.clientName}</div>
                      )}
                      <div className="flex items-center gap-2 mt-1.5">
                        <Badge variant="outline" className={`text-[9px] h-4 ${statusColor[c.status] || ""}`}>
                          {c.status}
                        </Badge>
                        {c.crime && (
                          <span className="text-[10px] text-muted-foreground">{c.crime}</span>
                        )}
                      </div>
                      {c._count && (c._count.pieces > 0 || c._count.notes > 0) && (
                        <div className="text-[10px] text-gold/60 mt-1 flex items-center gap-2">
                          <span>{c._count.pieces} peças</span>
                          <span>·</span>
                          <span>{c._count.notes} notas</span>
                        </div>
                      )}
                    </div>
                    <Trash2
                      onClick={e => deleteCase(c.id, e)}
                      className="h-3 w-3 opacity-0 group-hover:opacity-60 hover:opacity-100 text-forensic shrink-0 mt-1"
                    />
                  </div>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </Card>

      {/* Detalhe do caso */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        {!activeCase ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
            <FolderKanban className="h-12 w-12 text-gold/30" />
            <div className="space-y-1.5">
              <h3 className="text-lg font-serif">Biblioteca de casos</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                Cada caso reúne peças, anotações e conversas. Crie um caso para cada cliente ou processo.
              </p>
            </div>
          </div>
        ) : (
          <>
            <div className="p-4 border-b border-border">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <h2 className="text-lg font-serif text-gold">{activeCase.title}</h2>
                  {activeCase.clientName && (
                    <p className="text-sm text-foreground/80 mt-1">Cliente: {activeCase.clientName}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2 text-[11px]">
                    {activeCase.caseNumber && (
                      <span className="font-mono text-muted-foreground">{activeCase.caseNumber}</span>
                    )}
                    {activeCase.crime && (
                      <Badge variant="outline" className="text-[10px] border-forensic/30 text-forensic">
                        {activeCase.crime}
                      </Badge>
                    )}
                    <Badge variant="outline" className={`text-[10px] ${statusColor[activeCase.status]}`}>
                      {activeCase.status}
                    </Badge>
                  </div>
                </div>
              </div>
              {activeCase.summary && (
                <p className="text-xs text-foreground/70 mt-3 leading-relaxed">{activeCase.summary}</p>
              )}
            </div>

            <ScrollArea className="flex-1 scroll-thin">
              <div className="p-4 space-y-4">
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-gold font-semibold mb-2 flex items-center gap-2">
                    <FileText className="h-3 w-3" /> Peças ({activeCase.pieces?.length || 0})
                  </div>
                  {activeCase.pieces && activeCase.pieces.length > 0 ? (
                    <div className="space-y-2">
                      {activeCase.pieces.map(p => (
                        <Card key={p.id} className="p-3 border-border hover:border-gold/30 transition-colors cursor-pointer">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-foreground">{p.title}</div>
                              <div className="text-[10px] text-muted-foreground mt-0.5">
                                {p.pieceType} · atualizada {new Date(p.updatedAt).toLocaleDateString("pt-BR")}
                              </div>
                              <p className="text-xs text-foreground/60 mt-1.5 line-clamp-2">{p.content}</p>
                            </div>
                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
                          </div>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground italic">
                      Nenhuma peça. Use o Gerador de Peças e clique em "Salvar".
                    </p>
                  )}
                </div>
              </div>
            </ScrollArea>
          </>
        )}
      </Card>
    </div>
  );
}
