"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Send,
  Search,
  Scale,
  FileText,
  Sparkles,
  Trash2,
  Plus,
  Loader2,
  ExternalLink,
  MessageSquare,
} from "lucide-react";

interface Message {
  role: "user" | "assistant" | "system";
  content: string;
  sources?: { web: any[]; local: any[] };
}

interface Conversation {
  id: string;
  title: string;
  mode: string;
  updatedAt: string;
  _count?: { messages: number };
}

const PIECE_TYPES = [
  { value: "habeas_corpus", label: "Habeas Corpus" },
  { value: "apelacao", label: "Apelação" },
  { value: "rese", label: "Recurso em Sentido Estrito" },
  { value: "revisao", label: "Revisão Criminal" },
  { value: "embargos_declaracao", label: "Embargos de Declaração" },
  { value: "embargos_infringentes", label: "Embargos Infringentes" },
  { value: "queixa_crime", label: "Queixa-Crime" },
  { value: "liberdade_provisoria", label: "Liberdade Provisória" },
  { value: "relaxamento_prisao", label: "Relaxamento de Prisão" },
  { value: "outros", label: "Outros" },
];

export function ChatTab() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  async function loadConversations() {
    setLoadingConvs(true);
    try {
      const res = await fetch("/api/conversations");
      const data = await res.json();
      setConversations(data.conversations || []);
    } catch (err) {
      toast({ title: "Erro ao carregar conversas", variant: "destructive" });
    } finally {
      setLoadingConvs(false);
    }
  }

  async function newConversation() {
    try {
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "Nova conversa", mode: "chat" }),
      });
      const data = await res.json();
      const conv = data.conversation;
      setConversations([conv, ...conversations]);
      setActiveConversation(conv);
      setMessages([]);
    } catch (err) {
      toast({ title: "Erro ao criar conversa", variant: "destructive" });
    }
  }

  async function selectConversation(conv: Conversation) {
    setActiveConversation(conv);
    try {
      const res = await fetch(`/api/conversations/${conv.id}`);
      const data = await res.json();
      const convMessages = (data.conversation.messages || []).map((m: any) => {
        let parsedSources: any = undefined;
        if (m.sources) {
          try {
            parsedSources = JSON.parse(m.sources);
          } catch {}
        }
        return {
          role: m.role,
          content: m.content,
          sources: parsedSources,
        };
      });
      setMessages(convMessages);
    } catch (err) {
      toast({ title: "Erro ao carregar conversa", variant: "destructive" });
    }
  }

  async function deleteConversation(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    try {
      await fetch(`/api/conversations/${id}`, { method: "DELETE" });
      setConversations(conversations.filter(c => c.id !== id));
      if (activeConversation?.id === id) {
        setActiveConversation(null);
        setMessages([]);
      }
      toast({ title: "Conversa excluída" });
    } catch (err) {
      toast({ title: "Erro ao excluir", variant: "destructive" });
    }
  }

  async function sendMessage() {
    if (!input.trim() || streaming) return;

    let convId = activeConversation?.id;
    if (!convId) {
      try {
        const res = await fetch("/api/conversations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: input.slice(0, 60), mode: "chat" }),
        });
        const data = await res.json();
        convId = data.conversation.id;
        setConversations([data.conversation, ...conversations]);
        setActiveConversation(data.conversation);
      } catch {
        toast({ title: "Erro ao criar conversa", variant: "destructive" });
        return;
      }
    }

    const userMsg: Message = { role: "user", content: input };
    const assistantMsg: Message = { role: "assistant", content: "" };
    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setInput("");
    setStreaming(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })),
          conversationId: convId,
          useSearch: true,
        }),
      });

      if (!res.body) throw new Error("Sem resposta do servidor");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === "chunk") {
              setMessages(prev => {
                const copy = [...prev];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  content: copy[copy.length - 1].content + evt.content,
                };
                return copy;
              });
            } else if (evt.type === "sources") {
              setMessages(prev => {
                const copy = [...prev];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  sources: evt,
                };
                return copy;
              });
            } else if (evt.type === "error") {
              toast({ title: "Erro: " + evt.error, variant: "destructive" });
            }
          } catch {}
        }
      }
      loadConversations();
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setStreaming(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4 h-full">
      {/* Sidebar conversas */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <span className="text-xs uppercase tracking-widest text-gold font-semibold">Conversas</span>
          <Button size="sm" variant="ghost" onClick={newConversation} className="h-7 w-7 p-0 hover:text-gold">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-2 space-y-1">
            {loadingConvs ? (
              <div className="p-4 text-center text-xs text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                Carregando...
              </div>
            ) : conversations.length === 0 ? (
              <div className="p-4 text-center text-xs text-muted-foreground">
                Nenhuma conversa. Clique em + para começar.
              </div>
            ) : (
              conversations.map(conv => (
                <button
                  key={conv.id}
                  onClick={() => selectConversation(conv)}
                  className={`group w-full text-left p-2 rounded-md text-xs hover:bg-sidebar-accent transition-colors flex items-start justify-between gap-2 ${
                    activeConversation?.id === conv.id ? "bg-sidebar-accent border-l-2 border-gold" : ""
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="truncate text-foreground/90">{conv.title}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">
                      {conv._count?.messages || 0} msgs
                    </div>
                  </div>
                  <Trash2
                    onClick={e => deleteConversation(conv.id, e)}
                    className="h-3 w-3 opacity-0 group-hover:opacity-60 hover:opacity-100 text-forensic shrink-0 mt-1"
                  />
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </Card>

      {/* Área de chat */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-gold" />
            <span className="text-sm font-semibold text-gold">
              {activeConversation ? activeConversation.title : "Novo chat"}
            </span>
          </div>
          <Badge variant="outline" className="border-gold/40 text-gold text-[10px]">
            GLM 5.2 · Persona Juristas
          </Badge>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto scroll-thin p-4 space-y-4">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
              <Scale className="h-12 w-12 text-gold/40" />
              <div className="space-y-2 max-w-md">
                <h3 className="text-lg font-serif text-foreground">
                  JUS·AI Criminal pronto para atuar
                </h3>
                <p className="text-sm text-muted-foreground">
                  Agente sênior com persona de Aury Lopes Jr, Badaró, Bottini e Nucci.
                  Faça uma pergunta jurídica ou peça uma peça processual.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 justify-center max-w-lg">
                {[
                  "Quando cabe HC versus RESE?",
                  "Cadeia de custódia em tráfico de drogas",
                  "Estratégia para júri — legitima defesa",
                  "Resumo do art. 593, III CPP",
                ].map(sug => (
                  <button
                    key={sug}
                    onClick={() => setInput(sug)}
                    className="text-[11px] px-3 py-1.5 rounded-md border border-border hover:border-gold hover:text-gold transition-colors"
                  >
                    {sug}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] space-y-2 ${msg.role === "user" ? "items-end" : "items-start"} flex flex-col`}>
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                  {msg.role === "user" ? (
                    <>Você</>
                  ) : (
                    <>
                      <Scale className="h-3 w-3 text-gold" />
                      JUS·AI Criminal
                    </>
                  )}
                </div>
                <div
                  className={`rounded-lg px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed ${
                    msg.role === "user"
                      ? "bg-secondary text-secondary-foreground"
                      : "bg-card border border-border text-card-foreground"
                  }`}
                >
                  {msg.content || (streaming && i === messages.length - 1 ? (
                    <span className="typing-cursor"></span>
                  ) : "...")}
                </div>

                {/* Fontes */}
                {msg.sources && (msg.sources.web?.length > 0 || msg.sources.local?.length > 0) && (
                  <div className="mt-2 w-full space-y-2">
                    {msg.sources.local && msg.sources.local.length > 0 && (
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-gold/70 font-semibold mb-1 flex items-center gap-1">
                          <FileText className="h-3 w-3" /> Base legal local
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {msg.sources.local.map((art: any, idx: number) => (
                            <Badge key={idx} variant="outline" className="text-[10px] border-gold/30 text-gold">
                              {art.code} art. {art.article}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {msg.sources.web && msg.sources.web.length > 0 && (
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-forensic/70 font-semibold mb-1 flex items-center gap-1">
                          <Search className="h-3 w-3" /> Fontes web
                        </div>
                        <div className="space-y-1">
                          {msg.sources.web.map((src: any, idx: number) => (
                            <a
                              key={idx}
                              href={src.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="block text-[11px] px-2 py-1 rounded border border-border hover:border-forensic/40 hover:text-forensic transition-colors"
                            >
                              <div className="flex items-center gap-1">
                                <ExternalLink className="h-2.5 w-2.5 shrink-0" />
                                <span className="truncate">{src.title || src.url}</span>
                              </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 border-t border-border">
          <div className="flex gap-2 items-end">
            <Textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Pergunte sobre direito penal, peças, jurisprudência, estratégia..."
              className="resize-none min-h-[44px] max-h-32 text-sm bg-background border-border focus-visible:ring-gold"
              disabled={streaming}
            />
            <Button
              onClick={sendMessage}
              disabled={!input.trim() || streaming}
              className="bg-primary hover:bg-primary/90 text-primary-foreground shrink-0"
            >
              {streaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
          <div className="text-[10px] text-muted-foreground mt-1.5 flex items-center gap-1">
            <Sparkles className="h-2.5 w-2.5 text-gold/60" />
            Enter envia · Shift+Enter quebra linha · Busca jurisprudência automática
          </div>
        </div>
      </Card>
    </div>
  );
}
