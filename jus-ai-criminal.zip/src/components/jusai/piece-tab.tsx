"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectGroup,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  FileText,
  Loader2,
  Copy,
  Save,
  Scale,
  Search,
  Sparkles,
  ExternalLink,
  BookOpen,
  Clock,
  Gavel,
  ChevronDown,
  ChevronRight,
  Lightbulb,
} from "lucide-react";
import { PIECE_CATALOG, getPiecesByCategory } from "@/lib/piece-catalog";

interface PieceModel {
  title: string;
  url: string;
  snippet: string;
  queryType?: string;
}

interface PieceResult {
  piece: string;
  pieceType: string;
  pieceInfo?: {
    id: string;
    name: string;
    category: string;
    legalBasis: string;
    deadline: string;
    addressedTo: string;
    strategyHint: string;
  } | null;
  sources: { web: any[]; local: any[] };
  generatedAt: string;
}

export function PieceTab() {
  const [selectedPieceId, setSelectedPieceId] = useState<string>("");
  const [caseFacts, setCaseFacts] = useState("");
  const [clientData, setClientData] = useState("");
  const [courtAddress, setCourtAddress] = useState("");
  const [caseNumber, setCaseNumber] = useState("");
  const [additionalContext, setAdditionalContext] = useState("");
  const [useSearch, setUseSearch] = useState(true);

  const [generating, setGenerating] = useState(false);
  const [searchingModels, setSearchingModels] = useState(false);
  const [result, setResult] = useState<PieceResult | null>(null);
  const [models, setModels] = useState<PieceModel[]>([]);
  const [showModels, setShowModels] = useState(false);
  const [pieceInfo, setPieceInfo] = useState<any>(null);

  const { toast } = useToast();
  const grouped = getPiecesByCategory();
  const selectedPiece = selectedPieceId ? PIECE_CATALOG.find(p => p.id === selectedPieceId) : null;

  async function searchModels() {
    if (!selectedPieceId) {
      toast({ title: "Selecione uma peça primeiro", variant: "destructive" });
      return;
    }
    setSearchingModels(true);
    setModels([]);
    setShowModels(true);
    try {
      const res = await fetch("/api/piece-models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pieceId: selectedPieceId }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setModels(data.models || []);
      setPieceInfo(data.piece);
      toast({
        title: `${data.models?.length || 0} modelos encontrados`,
        description: "Modelos e jurisprudência da web prontos para consulta.",
      });
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setSearchingModels(false);
    }
  }

  async function generate() {
    if (!selectedPieceId || !caseFacts) {
      toast({ title: "Selecione a peça e descreva os fatos", variant: "destructive" });
      return;
    }
    setGenerating(true);
    setResult(null);

    try {
      const res = await fetch("/api/piece", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pieceId: selectedPieceId,
          caseFacts,
          clientData,
          courtAddress,
          caseNumber,
          additionalContext,
          useSearch,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setResult(data);
      toast({
        title: "Peça gerada com sucesso",
        description: selectedPiece ? `${selectedPiece.name} · ${selectedPiece.legalBasis}` : "Revise antes de protocolizar.",
      });
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  }

  function copyPiece() {
    if (!result?.piece) return;
    navigator.clipboard.writeText(result.piece);
    toast({ title: "Peça copiada para a área de transferência" });
  }

  async function savePiece() {
    if (!result?.piece) return;
    try {
      const caseRes = await fetch("/api/cases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `Caso — ${result.pieceType}`,
          summary: caseFacts.slice(0, 200),
          status: "ativo",
        }),
      });
      const caseData = await caseRes.json();
      await fetch("/api/pieces", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caseId: caseData.case.id,
          title: result.pieceType,
          pieceType: result.pieceType,
          content: result.piece,
          jurisprudence: JSON.stringify(result.sources),
        }),
      });
      toast({ title: "Peça salva em novo caso" });
    } catch (err: any) {
      toast({ title: "Erro ao salvar: " + err.message, variant: "destructive" });
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[400px_1fr] gap-4 h-full">
      {/* Formulário */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2 text-sm font-semibold text-gold">
            <FileText className="h-4 w-4" />
            Gerador de Peças Penais
          </div>
          <p className="text-[11px] text-muted-foreground mt-1">
            {PIECE_CATALOG.length} peças · {Object.keys(grouped).length} categorias · GLM 5.2
          </p>
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4 space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-gold/80 flex items-center justify-between">
                <span>Tipo de peça *</span>
                {selectedPiece && (
                  <Badge variant="outline" className="text-[9px] border-gold/40 text-gold">
                    {selectedPiece.category}
                  </Badge>
                )}
              </Label>
              <Select value={selectedPieceId} onValueChange={(v) => { setSelectedPieceId(v); setModels([]); setPieceInfo(null); setShowModels(false); }}>
                <SelectTrigger className="bg-background border-border focus:ring-gold">
                  <SelectValue placeholder="Selecione a peça criminal..." />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(grouped).map(([category, pieces]) => (
                    <SelectGroup key={category}>
                      <SelectLabel className="text-gold uppercase tracking-widest text-[10px]">
                        {category}
                      </SelectLabel>
                      {pieces.map(p => (
                        <SelectItem key={p.id} value={p.id}>
                          <div className="flex flex-col">
                            <span className="text-sm">{p.name}</span>
                            <span className="text-[10px] text-muted-foreground">
                              {p.legalBasis} · {p.deadline}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Info da peça selecionada */}
            {selectedPiece && (
              <Card className="p-3 border-gold/20 bg-gold/5 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-gold">{selectedPiece.name}</div>
                    <div className="text-[10px] text-muted-foreground font-mono mt-0.5">
                      {selectedPiece.legalBasis}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-foreground/80 leading-relaxed">
                  {selectedPiece.description}
                </p>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="h-3 w-3 text-gold" />
                    <span>{selectedPiece.deadline}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Gavel className="h-3 w-3 text-gold" />
                    <span className="truncate">{selectedPiece.addressedTo}</span>
                  </div>
                </div>
                <div className="border-t border-gold/20 pt-2 mt-1">
                  <div className="flex items-start gap-1.5 text-[11px] text-foreground/80">
                    <Lightbulb className="h-3 w-3 text-forensic shrink-0 mt-0.5" />
                    <span className="italic">{selectedPiece.strategyHint}</span>
                  </div>
                </div>
              </Card>
            )}

            {/* Botão buscar modelos */}
            {selectedPiece && (
              <Button
                onClick={searchModels}
                disabled={searchingModels}
                variant="outline"
                className="w-full border-forensic/40 text-forensic hover:bg-forensic/10 text-xs"
              >
                {searchingModels ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin mr-2" />
                    Buscando modelos na web...
                  </>
                ) : (
                  <>
                    <Search className="h-3.5 w-3.5 mr-2" />
                    Buscar modelos e exemplos na web
                  </>
                )}
              </Button>
            )}

            {/* Modelos encontrados */}
            {showModels && (
              <div className="space-y-2">
                <button
                  onClick={() => setShowModels(!showModels)}
                  className="flex items-center gap-1 text-[10px] uppercase tracking-widest text-forensic font-semibold w-full"
                >
                  {showModels ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                  {models.length} modelos encontrados
                </button>
                {searchingModels && (
                  <div className="text-[11px] text-muted-foreground italic flex items-center gap-1">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Buscando em JusBrasil, STJ, STF...
                  </div>
                )}
                {!searchingModels && models.length > 0 && (
                  <div className="space-y-1.5 max-h-64 overflow-y-auto scroll-thin pr-1">
                    {models.map((m, i) => (
                      <a
                        key={i}
                        href={m.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block p-2 rounded border border-border hover:border-forensic/40 transition-colors group"
                      >
                        <div className="flex items-start gap-1.5">
                          <ExternalLink className="h-3 w-3 text-forensic/60 shrink-0 mt-0.5 group-hover:text-forensic" />
                          <div className="flex-1 min-w-0">
                            <div className="text-[11px] text-foreground truncate group-hover:text-forensic">
                              {m.title || m.url}
                            </div>
                            <div className="text-[9px] text-muted-foreground truncate mt-0.5">
                              {m.url}
                            </div>
                            {m.snippet && (
                              <p className="text-[10px] text-foreground/60 line-clamp-2 mt-1">
                                {m.snippet}
                              </p>
                            )}
                          </div>
                        </div>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="border-t border-border pt-3 space-y-3">
              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-gold/80">
                  Qualificação do cliente
                </Label>
                <Textarea
                  value={clientData}
                  onChange={e => setClientData(e.target.value)}
                  placeholder="Nome, nacionalidade, estado civil, profissão, RG, CPF, endereço..."
                  className="resize-none min-h-[60px] bg-background border-border focus-visible:ring-gold text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-gold/80">
                  Endereçamento (juízo/tribunal)
                </Label>
                <Input
                  value={courtAddress}
                  onChange={e => setCourtAddress(e.target.value)}
                  placeholder={selectedPiece?.addressedTo || "Ex: Egrégio Tribunal de Justiça de São Paulo"}
                  className="bg-background border-border focus-visible:ring-gold text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-gold/80">
                  Número do processo
                </Label>
                <Input
                  value={caseNumber}
                  onChange={e => setCaseNumber(e.target.value)}
                  placeholder="0000000-00.0000.0.00.0000"
                  className="bg-background border-border focus-visible:ring-gold text-sm font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-gold/80">
                  Fatos do caso *
                </Label>
                <Textarea
                  value={caseFacts}
                  onChange={e => setCaseFacts(e.target.value)}
                  placeholder="Descreva cronologicamente os fatos relevantes para a peça..."
                  className="resize-none min-h-[100px] bg-background border-border focus-visible:ring-gold text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-gold/80">
                  Contexto adicional (tese, precedentes, etc.)
                </Label>
                <Textarea
                  value={additionalContext}
                  onChange={e => setAdditionalContext(e.target.value)}
                  placeholder="Tese central pretendida, precedentes específicos, fundamentos doutrinários..."
                  className="resize-none min-h-[70px] bg-background border-border focus-visible:ring-gold text-sm"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer text-xs text-foreground/80">
                <input
                  type="checkbox"
                  checked={useSearch}
                  onChange={e => setUseSearch(e.target.checked)}
                  className="accent-gold"
                />
                <Search className="h-3 w-3 text-gold" />
                Buscar jurisprudência atualizada na web
              </label>
            </div>
          </div>
        </ScrollArea>

        <div className="p-3 border-t border-border">
          <Button
            onClick={generate}
            disabled={!selectedPieceId || !caseFacts || generating}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Gerando peça...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Gerar peça
              </>
            )}
          </Button>
        </div>
      </Card>

      {/* Resultado */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scale className="h-4 w-4 text-gold" />
            <span className="text-sm font-semibold text-gold">
              {result ? `Peça · ${result.pieceType}` : "Resultado"}
            </span>
          </div>
          {result && (
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={copyPiece} className="h-7 text-xs hover:text-gold">
                <Copy className="h-3 w-3 mr-1" /> Copiar
              </Button>
              <Button size="sm" variant="ghost" onClick={savePiece} className="h-7 text-xs hover:text-gold">
                <Save className="h-3 w-3 mr-1" /> Salvar
              </Button>
            </div>
          )}
        </div>

        <ScrollArea className="flex-1 scroll-thin">
          <div className="p-4">
            {generating && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <Loader2 className="h-10 w-10 text-gold animate-spin" />
                <div className="space-y-1">
                  <div className="text-sm text-gold">Construindo peça com GLM 5.2...</div>
                  <div className="text-xs text-muted-foreground max-w-md">
                    {selectedPiece && (
                      <>
                        Aplicando: {selectedPiece.legalBasis} · Prazo: {selectedPiece.deadline}<br/>
                        Estrutura: endereçamento · qualificação · fatos · fundamentação · pedido
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}

            {!generating && !result && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
                <FileText className="h-12 w-12 text-gold/30" />
                <div className="space-y-1.5">
                  <h3 className="text-lg font-serif">Catálogo de {PIECE_CATALOG.length} peças criminais</h3>
                  <p className="text-sm text-muted-foreground max-w-md">
                    Selecione uma peça no formulário. O agente redige com técnica de Aury Lopes Jr + Badaró + Bottini + Nucci.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2 max-w-lg text-left">
                  {Object.entries(grouped).slice(0, 6).map(([cat, pieces]) => (
                    <div key={cat} className="border border-border rounded p-2">
                      <div className="text-[10px] uppercase tracking-widest text-gold font-semibold">
                        {cat} <span className="text-muted-foreground">({pieces.length})</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-1">
                        {pieces.slice(0, 2).map(p => p.name).join(" · ")}
                        {pieces.length > 2 && " · ..."}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-[10px] text-muted-foreground/70 max-w-md italic">
                  ✦ Destaque: Resposta à Acusação · Memoriais · HC · Apelação · RESE · Agravo em Execução · Progressão · Remição · Livramento · Exceções · e mais
                </div>
              </div>
            )}

            {result && (
              <div className="space-y-4">
                {result.pieceInfo && (
                  <Card className="p-3 border-gold/20 bg-gold/5">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-gold">{result.pieceInfo.name}</div>
                        <div className="text-[10px] text-muted-foreground font-mono mt-0.5">
                          {result.pieceInfo.legalBasis} · {result.pieceInfo.deadline}
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[9px] border-forensic/40 text-forensic shrink-0">
                        {result.pieceInfo.category}
                      </Badge>
                    </div>
                  </Card>
                )}

                <div className="font-mono text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">
                  {result.piece}
                </div>

                {result.sources && (result.sources.local?.length > 0 || result.sources.web?.length > 0) && (
                  <div className="border-t border-border pt-4 space-y-3">
                    <div className="text-[10px] uppercase tracking-widest text-gold font-semibold flex items-center gap-1">
                      <BookOpen className="h-3 w-3" /> Fontes utilizadas
                    </div>
                    {result.sources.local?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {result.sources.local.map((art: any, i: number) => (
                          <Badge key={i} variant="outline" className="text-[10px] border-gold/30 text-gold">
                            {art.code} art. {art.article}
                          </Badge>
                        ))}
                      </div>
                    )}
                    {result.sources.web?.length > 0 && (
                      <div className="space-y-1">
                        {result.sources.web.map((src: any, i: number) => (
                          <a
                            key={i}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block text-[11px] text-forensic hover:underline"
                          >
                            [{i + 1}] {src.title}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="border-t border-border pt-3 text-[11px] text-muted-foreground italic">
                  ⚠️ Peça para revisão do advogado responsável antes da protocolização.
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
}
