"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Key,
  Loader2,
  Save,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Zap,
  ShieldCheck,
  Info,
} from "lucide-react";

export function ConfigTab() {
  const [baseUrl, setBaseUrl] = useState("https://api.z.ai/api/v1");
  const [apiKey, setApiKey] = useState("");
  const [userId, setUserId] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    sample?: string;
    model?: string;
  } | null>(null);
  const [usingCustom, setUsingCustom] = useState(false);
  const [configMode, setConfigMode] = useState<"env-var" | "project-file" | "system-fallback">("system-fallback");
  const [isServerless, setIsServerless] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    loadConfig();
  }, []);

  async function loadConfig() {
    setLoading(true);
    try {
      const res = await fetch("/api/config");
      const data = await res.json();
      setUsingCustom(data.usingCustom);
      setConfigMode(data.mode || "system-fallback");
      setIsServerless(data.isServerless || false);
      if (data.usingCustom && data.config) {
        setBaseUrl(data.config.baseUrl || "https://api.z.ai/api/v1");
        setUserId(data.config.userId || "");
        setApiKey("");
      }
    } catch {
      toast({ title: "Erro ao carregar config", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    if (!baseUrl || !apiKey) {
      toast({ title: "baseUrl e apiKey são obrigatórios", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ baseUrl, apiKey, userId }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      toast({ title: "✓ Config salvo", description: "Arquivo .z-ai-config criado no projeto" });
      setApiKey(""); // limpa após salvar
      setUsingCustom(true);
      setTestResult(null);
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function test() {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/config/test", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setTestResult({
          success: true,
          message: data.message,
          sample: data.sample,
          model: data.model,
        });
        toast({ title: "✓ Conexão validada", description: data.message });
      } else {
        setTestResult({
          success: false,
          message: data.error || "Falha na conexão",
        });
        toast({
          title: "✗ Falha na conexão",
          description: data.error,
          variant: "destructive",
        });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: err.message });
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    } finally {
      setTesting(false);
    }
  }

  async function reset() {
    if (!confirm("Remover config do projeto e voltar para o do sandbox (/etc/.z-ai-config)?")) {
      return;
    }
    try {
      await fetch("/api/config", { method: "DELETE" });
      setApiKey("");
      setUserId("");
      setBaseUrl("https://api.z.ai/api/v1");
      setUsingCustom(false);
      setTestResult(null);
      toast({ title: "Config removido", description: "Voltando para config do sandbox" });
    } catch (err: any) {
      toast({ title: "Erro: " + err.message, variant: "destructive" });
    }
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-4 h-full">
      {/* Formulário principal */}
      <Card className="flex flex-col h-full overflow-hidden p-0">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2 text-sm font-semibold text-gold">
            <Key className="h-4 w-4" />
            Configuração Z.AI API
          </div>
          <p className="text-[11px] text-muted-foreground mt-1">
            Cole sua chave Z.AI para usar GLM 5.2 com sua própria conta
          </p>
        </div>

        <div className="flex-1 overflow-y-auto scroll-thin p-4 space-y-4">
          {/* Status atual */}
          <div className={`rounded-md p-3 border ${
            configMode === "env-var"
              ? "border-forensic/40 bg-forensic/5"
              : usingCustom
              ? "bg-forensic/5 border-forensic/30"
              : "bg-gold/5 border-gold/30"
          }`}>
            <div className="flex items-center gap-2 mb-1">
              {configMode === "env-var" ? (
                <ShieldCheck className="h-4 w-4 text-forensic" />
              ) : usingCustom ? (
                <ShieldCheck className="h-4 w-4 text-forensic" />
              ) : (
                <Info className="h-4 w-4 text-gold" />
              )}
              <span className="text-xs uppercase tracking-widest font-semibold text-foreground">
                {configMode === "env-var"
                  ? "Chave via variável de ambiente (produção)"
                  : usingCustom
                  ? "Sua chave está salva"
                  : "Usando config do sandbox"}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {configMode === "env-var"
                ? "Configuração via ZAI_API_KEY/ZAI_BASE_URL — ideal para Vercel e produção. As chamadas ao GLM 5.2 usam sua conta."
                : usingCustom
                ? "Sua chave foi salva em .z-ai-config no projeto. Clique em \"Testar\" para validar."
                : "Você está usando o config do sandbox (/etc/.z-ai-config) — funciona neste ambiente."}
            </p>
          </div>

          {/* Aviso de ambiente serverless (Vercel) */}
          {isServerless && (
            <div className="rounded-md p-3 border border-forensic/40 bg-forensic/5">
              <div className="flex items-start gap-2">
                <ShieldCheck className="h-4 w-4 text-forensic shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="text-xs uppercase tracking-widest font-semibold text-forensic mb-1">
                    Ambiente Vercel/Serverless detectado
                  </div>
                  <p className="text-xs text-foreground/80">
                    Sua chave está sendo lida das variáveis de ambiente configuradas no painel da Vercel.
                    Para alterar, vá em <strong className="text-foreground">Vercel → Settings → Environment Variables</strong> e
                    atualize <code className="text-forensic">ZAI_API_KEY</code>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Aviso sobre sandbox (apenas se NÃO for serverless) */}
          {!isServerless && configMode !== "env-var" && (
            <div className="rounded-md p-3 border border-gold/30 bg-gold/5">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-gold shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="text-xs uppercase tracking-widest font-semibold text-gold mb-1">
                    Atenção — ambiente sandbox
                  </div>
                  <p className="text-xs text-foreground/80">
                    Este app está rodando num sandbox que bloqueia chamadas diretas para
                    <code className="text-gold mx-1">api.z.ai</code>
                    (erro SSL). Para funcionar aqui, use o config do sandbox (botão "Resetar" se você já salvou um).
                    Em <strong className="text-foreground">deploy próprio Vercel</strong>, sua chave Z.AI funciona normalmente.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* baseUrl */}
          <div className="space-y-1.5">
            <Label className="text-xs uppercase tracking-widest text-gold/80 flex items-center gap-1">
              <span>Base URL</span>
              <span className="text-forensic">*</span>
            </Label>
            <Input
              value={baseUrl}
              onChange={e => setBaseUrl(e.target.value)}
              placeholder="https://api.z.ai/api/v1"
              className="bg-background border-border focus-visible:ring-gold text-sm font-mono"
            />
            <p className="text-[10px] text-muted-foreground">
              Endpoint da API Z.AI. Padrão oficial: <code className="text-gold">https://api.z.ai/api/v1</code>
            </p>
          </div>

          {/* apiKey */}
          <div className="space-y-1.5">
            <Label className="text-xs uppercase tracking-widest text-gold/80 flex items-center gap-1">
              <span>API Key</span>
              <span className="text-forensic">*</span>
            </Label>
            <div className="relative">
              <Input
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder={usingCustom ? "•••••••• (chave já salva — cole nova para trocar)" : "Cole sua chave Z.AI aqui"}
                className="bg-background border-border focus-visible:ring-gold text-sm font-mono pr-10"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-gold"
              >
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground">
              Obtenha em <code className="text-gold">https://z.ai/manage-apikey/apikey-list</code> · Nunca compartilhe esta chave
            </p>
          </div>

          {/* userId */}
          <div className="space-y-1.5">
            <Label className="text-xs uppercase tracking-widest text-gold/80">
              User ID <span className="text-muted-foreground">(opcional)</span>
            </Label>
            <Input
              value={userId}
              onChange={e => setUserId(e.target.value)}
              placeholder="seu-user-id-zai (opcional)"
              className="bg-background border-border focus-visible:ring-gold text-sm font-mono"
            />
            <p className="text-[10px] text-muted-foreground">
              Identificador de usuário para tracking — opcional, mas recomendado
            </p>
          </div>

          {/* Botões */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={save}
              disabled={!baseUrl || !apiKey || saving}
              className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Salvar config
            </Button>
            <Button
              onClick={test}
              disabled={testing}
              variant="outline"
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              {testing ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Zap className="h-4 w-4 mr-2" />
              )}
              Testar
            </Button>
            {usingCustom && (
              <Button
                onClick={reset}
                variant="outline"
                className="border-forensic/40 text-forensic hover:bg-forensic/10"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Resultado do teste */}
          {testResult && (
            <Card className={`p-3 border-2 ${
              testResult.success ? "border-forensic/40 bg-forensic/5" : "border-destructive/40 bg-destructive/5"
            }`}>
              <div className="flex items-start gap-2">
                {testResult.success ? (
                  <CheckCircle2 className="h-5 w-5 text-forensic shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground">
                    {testResult.success ? "Conexão validada" : "Falha na conexão"}
                  </div>
                  <p className="text-xs text-foreground/80 mt-0.5">{testResult.message}</p>
                  {testResult.success && testResult.sample && (
                    <div className="mt-2 space-y-1">
                      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                        Resposta do GLM 5.2
                      </div>
                      <code className="text-xs text-gold font-mono block bg-muted/50 p-1.5 rounded">
                        {testResult.sample}
                      </code>
                      {testResult.model && (
                        <div className="text-[10px] text-muted-foreground">
                          Modelo: {testResult.model}
                        </div>
                      )}
                    </div>
                  )}
                  {!testResult.success && testResult.message?.includes("certificate") && (
                    <div className="mt-2 p-2 rounded bg-gold/10 border border-gold/30 text-[11px] text-foreground/80">
                      <strong className="text-gold">Erro SSL detectado.</strong> Este sandbox bloqueia
                      chamadas diretas para <code className="text-gold">api.z.ai</code>. Clique em
                      "Resetar" para voltar ao config do sandbox (que funciona aqui). Em deploy próprio,
                      sua chave funcionará normalmente.
                    </div>
                  )}
                </div>
              </div>
            </Card>
          )}
        </div>
      </Card>

      {/* Lateral — info e ajuda */}
      <Card className="p-4 space-y-3 h-full overflow-hidden flex flex-col">
        <div className="text-xs uppercase tracking-widest text-gold font-semibold flex items-center gap-2">
          <Info className="h-3.5 w-3.5" /> Como obter sua chave
        </div>
        <div className="space-y-3 text-xs text-foreground/80 flex-1 overflow-y-auto scroll-thin">
          <div className="space-y-2">
            <div className="flex items-start gap-2">
              <span className="font-mono text-gold shrink-0">01.</span>
              <div>
                <strong className="text-foreground">Acesse o painel Z.AI</strong>
                <p className="text-muted-foreground mt-0.5">
                  Visite <code className="text-gold">z.ai</code> e faça login na sua conta
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-mono text-gold shrink-0">02.</span>
              <div>
                <strong className="text-foreground">Vá em API Keys</strong>
                <p className="text-muted-foreground mt-0.5">
                  Manage API Key → Create new key
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-mono text-gold shrink-0">03.</span>
              <div>
                <strong className="text-foreground">Copie a chave</strong>
                <p className="text-muted-foreground mt-0.5">
                  Formato: <code className="text-gold">xxxxxxxx.z.ai</code> — long string
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-mono text-gold shrink-0">04.</span>
              <div>
                <strong className="text-foreground">Cole aqui e salve</strong>
                <p className="text-muted-foreground mt-0.5">
                  A chave fica salva em <code className="text-gold">.z-ai-config</code> no projeto
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-mono text-gold shrink-0">05.</span>
              <div>
                <strong className="text-foreground">Teste a conexão</strong>
                <p className="text-muted-foreground mt-0.5">
                  Clique em "Testar" para validar
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-3 mt-3">
            <div className="text-[10px] uppercase tracking-widest text-forensic font-semibold mb-2 flex items-center gap-1">
              <ShieldCheck className="h-3 w-3" /> Segurança
            </div>
            <ul className="space-y-1.5 text-[11px] text-muted-foreground">
              <li className="flex items-start gap-1.5">
                <span className="text-forensic mt-0.5">•</span>
                <span>A chave fica apenas no seu projeto local</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-forensic mt-0.5">•</span>
                <span>Arquivo com permissão 0600 (só dono lê)</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-forensic mt-0.5">•</span>
                <span>Nunca compartilhe ou comita em git</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-forensic mt-0.5">•</span>
                <span>Botão "Resetar" remove o arquivo</span>
              </li>
            </ul>
          </div>

          <div className="border-t border-border pt-3 mt-3">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
              Status atual
            </div>
            <Badge
              variant="outline"
              className={`text-[10px] ${
                usingCustom ? "border-forensic/40 text-forensic" : "border-gold/40 text-gold"
              }`}
            >
              {usingCustom ? "Sua chave ativa" : "Sandbox fallback"}
            </Badge>
          </div>
        </div>
      </Card>
    </div>
  );
}
