"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChatTab } from "@/components/jusai/chat-tab";
import { SearchTab } from "@/components/jusai/search-tab";
import { PieceTab } from "@/components/jusai/piece-tab";
import { StrategyTab } from "@/components/jusai/strategy-tab";
import { CasesTab } from "@/components/jusai/cases-tab";
import { ConfigTab } from "@/components/jusai/config-tab";
import { AudienciaTab } from "@/components/jusai/audiencia-tab";
import { Scale, MessageSquare, Search, FileText, Target, FolderKanban, Settings, Gavel, Sparkles } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("chat");

  return (
    <main className="min-h-screen flex flex-col bg-background bg-grain">
      {/* Topbar */}
      <header className="border-b border-border bg-sidebar/50 backdrop-blur-sm">
        <div className="px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-md bg-primary/10 border border-gold/30 flex items-center justify-center glow-gold">
              <Scale className="h-5 w-5 text-gold" />
            </div>
            <div>
              <h1 className="text-base font-serif font-bold tracking-tight text-gold">
                JUS·AI Criminal
              </h1>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                Agente Jurídico Sênior · Direito Penal Brasileiro
              </p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3 text-gold" />
            <span>Powered by GLM 5.2</span>
            <span className="text-border">·</span>
            <span className="text-gold/80">Persona: Aury Lopes Jr + Badaró + Bottini + Nucci</span>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 p-4 lg:p-6 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-7 max-w-4xl mb-4 bg-card border border-border">
            <TabsTrigger value="chat" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Chat</span>
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <Search className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Busca</span>
            </TabsTrigger>
            <TabsTrigger value="piece" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <FileText className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Peças</span>
            </TabsTrigger>
            <TabsTrigger value="strategy" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <Target className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Estratégia</span>
            </TabsTrigger>
            <TabsTrigger value="audiencia" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <Gavel className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Audiências</span>
            </TabsTrigger>
            <TabsTrigger value="cases" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <FolderKanban className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Casos</span>
            </TabsTrigger>
            <TabsTrigger value="config" className="data-[state=active]:bg-primary/10 data-[state=active]:text-gold text-xs">
              <Settings className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Config</span>
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 min-h-0">
            <TabsContent value="chat" className="h-full m-0">
              <ChatTab />
            </TabsContent>
            <TabsContent value="search" className="h-full m-0">
              <SearchTab />
            </TabsContent>
            <TabsContent value="piece" className="h-full m-0">
              <PieceTab />
            </TabsContent>
            <TabsContent value="strategy" className="h-full m-0">
              <StrategyTab />
            </TabsContent>
            <TabsContent value="audiencia" className="h-full m-0">
              <AudienciaTab />
            </TabsContent>
            <TabsContent value="cases" className="h-full m-0">
              <CasesTab />
            </TabsContent>
            <TabsContent value="config" className="h-full m-0">
              <ConfigTab />
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-border bg-sidebar/50 backdrop-blur-sm py-2 px-6">
        <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="uppercase tracking-widest">JUS·AI Criminal v1.0</span>
            <span className="text-border">·</span>
            <span>Web Search · Web Reader · Base CP/CPP/CF · Memória Local</span>
          </div>
          <div className="italic text-gold/60">
            "A defesa técnica começa no inquérito, não na sentença." — Aury Lopes Jr
          </div>
        </div>
      </footer>
    </main>
  );
}
