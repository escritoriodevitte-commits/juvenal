import { NextRequest, NextResponse } from "next/server";
import { webRead } from "@/lib/zai-service";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const { url } = await req.json();
    if (!url) {
      return NextResponse.json({ error: "url é obrigatório" }, { status: 400 });
    }
    const result = await webRead(url);
    if (!result) {
      return NextResponse.json({ error: "Não foi possível ler a página" }, { status: 502 });
    }
    return NextResponse.json(result);
  } catch (err: any) {
    console.error("Reader API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
