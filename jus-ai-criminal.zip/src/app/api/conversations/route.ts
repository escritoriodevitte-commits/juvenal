import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

// GET /api/conversations — lista conversas
export async function GET() {
  try {
    const conversations = await db.conversation.findMany({
      orderBy: { updatedAt: "desc" },
      include: { _count: { select: { messages: true } } },
    });
    return NextResponse.json({ conversations });
  } catch (err: any) {
    console.error("Error listing conversations:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// POST /api/conversations — cria conversa
export async function POST(req: NextRequest) {
  try {
    const { title, mode = "chat", caseId } = await req.json();
    const conversation = await db.conversation.create({
      data: { title: title || "Nova conversa", mode, caseId },
    });
    return NextResponse.json({ conversation });
  } catch (err: any) {
    console.error("Error creating conversation:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
