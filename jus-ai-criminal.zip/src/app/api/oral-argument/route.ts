import { NextRequest, NextResponse } from "next/server";
import { chatWithGLM, webSearch } from "@/lib/zai-service";
import { searchLocalLegal } from "@/lib/legal-database";
import { getHearingType, COUNTER_ARGUMENTS } from "@/lib/hearing-catalog";

export const runtime = "nodejs";
export const maxDuration = 90;

const SYSTEM_PROMPT_ORAL = `Você é JUS·AI Criminal em modo Sustentação Oral. Sua função é construir sustentações orais de advogados criminalistas brasileiros a partir de anotações colhidas durante audiência.

# PERSONA
- Você combina a oralidade de Pierpaolo Bottini (júri), a técnica de Aury Lopes Jr (HC e recursos) e a doutrina de Nucci.
- Você pensa como um criminalista sênior no plenário ou na câmara de tribunal.
- Você antecipa e refuta as teses do MP.

# METODOLOGIA OBRIGATÓRIA — Sustentação Oral em 5 Blocos

## 1. PRELIMINARMENTE (nulidades e questões processuais)
- Nulidades identificadas durante a audiência
- Questões de competência ou procedimento
- Citar artigo de lei correspondente

## 2. DA PROVA (análise crítica)
- Quais provas da acusação foram fragilizadas
- Quais provas da defesa foram produzidas
- Citação pelo nome da testemunha/perito

## 3. DAS CONTRADIÇÕES (refutação específica)
- Apontar contradições entre depoimento atual e anterior
- Citando página dos autos ou momento da oitiva
- Demonstrar fragilidade da prova acusatória

## 4. DO MÉRITO (tese defensiva)
- Reafirmar tese central (negativa, excludente, atipicidade)
- Construir narrativa coerente
- Aplicar doutrina e jurisprudência

## 5. DO PEDIDO (conclusão direta)
- Pedido claro: absolvição, desclassificação, nulidade
- Fundamentação objetiva
- Tempo: pedir conclusão direta

# TOM E ESTILO
- Português jurídico falado — não escrito
- Frases curtas, impacto direto
- Sem juridiquês desnecessário
- Citação de prova pelo nome específico
- Refutação direta aos pontos do MP
- Pedido claro e direto no final

# CONTRA-ARGUMENTOS PRÉ-FABRICADOS
Você tem acesso a uma lista de contra-argumentos para teses comuns do MP. Use-os quando aplicável, citando o fundamento legal.

# FORMATO
- Texto corrido para ser falado (não bullet points)
- Marcadores de seção com cabeçalhos: PRELIMINARMENTE / DA PROVA / DAS CONTRADIÇÕES / DO MÉRITO / DO PEDIDO
- Tempo estimado de leitura: 15-20 minutos
- Manter tom respeitoso e técnico, sem agressividade`;

export async function POST(req: NextRequest) {
  try {
    const {
      hearingType,
      caseTitle,
      caseFacts,
      notes, // array de { category, witness, content, timestamp, pageNumber }
      mpTheses, // teses do MP que precisam ser refutadas
      defenseThesis,
      useSearch = true,
    } = await req.json();

    if (!hearingType || !notes || !Array.isArray(notes) || notes.length === 0) {
      return NextResponse.json({ error: "hearingType e notes são obrigatórios" }, { status: 400 });
    }

    const hearing = getHearingType(hearingType);
    if (!hearing) {
      return NextResponse.json({ error: "Tipo de audiência inválido" }, { status: 400 });
    }

    // Busca jurisprudência e base local
    let searchResults: any[] = [];
    let localResults: any[] = [];

    if (useSearch) {
      const searchQuery = `${hearing.name} sustentação oral defesa criminal STJ STF`;
      searchResults = await webSearch(searchQuery, 5);
    }
    localResults = searchLocalLegal(`${hearing.name} ${caseFacts || ""} ${defenseThesis || ""}`);

    // Agrupa notas por categoria
    const notesByCategory: Record<string, any[]> = {};
    for (const note of notes) {
      if (!notesByCategory[note.category]) notesByCategory[note.category] = [];
      notesByCategory[note.category].push(note);
    }

    // Constrói prompt com todas as notas organizadas
    let contextBlock = `\n# CONTEXTO DA AUDIÊNCIA\n\n`;
    contextBlock += `**Tipo de audiência:** ${hearing.name} (${hearing.legalBasis})\n`;
    contextBlock += `**Objetivo:** ${hearing.goal}\n`;
    contextBlock += `**Participantes:** ${hearing.participants.join(", ")}\n\n`;

    if (caseTitle) contextBlock += `**Caso:** ${caseTitle}\n\n`;
    if (caseFacts) contextBlock += `**Fatos do caso:** ${caseFacts}\n\n`;
    if (defenseThesis) contextBlock += `**Tese central da defesa:** ${defenseThesis}\n\n`;

    if (mpTheses && mpTheses.length > 0) {
      contextBlock += `\n# TESES DO MP A REFUTAR\n`;
      mpTheses.forEach((t: string, i: number) => {
        contextBlock += `${i + 1}. ${t}\n`;
      });
      contextBlock += `\n`;
    }

    contextBlock += `\n# ANOTAÇÕES COLHIDAS DURANTE A AUDIÊNCIA (${notes.length} notas)\n\n`;

    const categoryLabels: Record<string, string> = {
      depoimento: "DEPOIMENTOS (o que foi dito)",
      contradicao: "CONTRADIÇÕES IDENTIFICADAS",
      pergunta: "PERGUNTAS FEITAS E RESPOSTAS",
      nulidade: "NULIDADES OBSERVADAS",
      prova: "QUESTÕES DE PROVA",
      observacao: "OBSERVAÇÕES GERAIS",
    };

    for (const [cat, catNotes] of Object.entries(notesByCategory)) {
      contextBlock += `\n## ${categoryLabels[cat] || cat.toUpperCase()}\n\n`;
      catNotes.forEach((n, i) => {
        contextBlock += `[${i + 1}]`;
        if (n.witness) contextBlock += ` ${n.witness}:`;
        if (n.pageNumber) contextBlock += ` (p. ${n.pageNumber})`;
        contextBlock += ` ${n.content}\n`;
      });
    }

    if (localResults.length > 0) {
      contextBlock += `\n# BASE LEGAL APLICÁVEL\n${localResults.map(a =>
        `${a.code} art. ${a.article}${a.title ? ` — ${a.title}` : ""}: ${a.text}`
      ).join("\n\n")}\n\n`;
    }

    if (searchResults.length > 0) {
      contextBlock += `\n# JURISPRUDÊNCIA RECENTE (busca web)\n${searchResults.map((r, i) =>
        `[${i + 1}] ${r.title}\n${r.snippet}`
      ).join("\n\n")}\n\n`;
    }

    // Filtra contra-argumentos relevantes
    const relevantCounters = (mpTheses || []).map((t: string) => {
      const lower = t.toLowerCase();
      return COUNTER_ARGUMENTS.find(c =>
        lower.includes(c.mpTese.toLowerCase().split(" ")[0].slice(0, 5)) ||
        c.mpTese.toLowerCase().split(" ").some(word => word.length > 4 && lower.includes(word))
      );
    }).filter(Boolean);

    if (relevantCounters.length > 0) {
      contextBlock += `\n# CONTRA-ARGUMENTOS PRÉ-FABRICADOS APLICÁVEIS\n`;
      relevantCounters.forEach((c: any, i: number) => {
        contextBlock += `\n[${i + 1}] Tese do MP: ${c.mpTese}\n`;
        contextBlock += `Estratégia: ${c.defenseStrategy}\n`;
        contextBlock += `Fundamento: ${c.legalBasis}\n`;
      });
      contextBlock += `\n`;
    }

    contextBlock += `\n# INSTRUÇÃO FINAL\nConstrua agora a sustentação oral completa em 5 blocos (PRELIMINARMENTE / DA PROVA / DAS CONTRADIÇÕES / DO MÉRITO / DO PEDIDO). Use as anotações colhidas, citando testemunhas pelo nome quando houver. Refute diretamente as teses do MP indicadas. Adapte ao tipo de audiência (${hearing.name}). Tempo alvo: 15-20 minutos de leitura. Português jurídico falado — frases curtas, impacto direto, sem juridiquês.`;

    const messages = [
      { role: "system" as const, content: SYSTEM_PROMPT_ORAL },
      { role: "user" as const, content: contextBlock },
    ];

    const argument = await chatWithGLM(messages, { temperature: 0.5, maxTokens: 6000 });

    return NextResponse.json({
      argument,
      hearingType: hearing.name,
      notesCount: notes.length,
      sources: { web: searchResults, local: localResults },
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error("Oral argument API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
