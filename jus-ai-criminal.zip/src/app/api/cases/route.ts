import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  try {
    const cases = await db.case.findMany({
      orderBy: { updatedAt: "desc" },
      include: { _count: { select: { pieces: true, notes: true } } },
    });
    return NextResponse.json({ cases });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { title, clientName, caseNumber, crime, summary, status } = await req.json();
    if (!title) {
      return NextResponse.json({ error: "title é obrigatório" }, { status: 400 });
    }
    const newCase = await db.case.create({
      data: { title, clientName, caseNumber, crime, summary, status: status || "ativo" },
    });
    return NextResponse.json({ case: newCase });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
