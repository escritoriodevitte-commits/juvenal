import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const caseData = await db.case.findUnique({
      where: { id },
      include: {
        pieces: { orderBy: { updatedAt: "desc" } },
        notes: { orderBy: { createdAt: "desc" } },
      },
    });
    if (!caseData) {
      return NextResponse.json({ error: "Caso não encontrado" }, { status: 404 });
    }
    return NextResponse.json({ case: caseData });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { title, clientName, caseNumber, crime, summary, status } = await req.json();
    const updated = await db.case.update({
      where: { id },
      data: { title, clientName, caseNumber, crime, summary, status },
    });
    return NextResponse.json({ case: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.case.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
