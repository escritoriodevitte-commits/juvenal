import { NextRequest, NextResponse } from "next/server";
import { chatWithGLM, webSearch } from "@/lib/zai-service";
import { SYSTEM_PROMPT_PIECE } from "@/lib/persona";
import { searchLocalLegal } from "@/lib/legal-database";
import { getPieceById } from "@/lib/piece-catalog";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const {
      pieceId,
      pieceType: pieceTypeOverride,
      caseFacts,
      clientData,
      courtAddress,
      caseNumber,
      additionalContext,
      useSearch = true,
    } = await req.json();

    // Resolve peça: por ID do catálogo OU nome override (compat)
    let piece = pieceId ? getPieceById(pieceId) : undefined;
    const pieceType = piece?.name || pieceTypeOverride;

    if (!pieceType || !caseFacts) {
      return NextResponse.json({ error: "pieceId/pieceType e caseFacts são obrigatórios" }, { status: 400 });
    }

    // Busca jurisprudência e base local
    let searchResults: any[] = [];
    let localResults: any[] = [];

    if (useSearch) {
      const searchQuery = piece?.searchQuery || `${pieceType} jurisprudência STJ STF Brasil`;
      searchResults = await webSearch(searchQuery, 6);
    }
    localResults = searchLocalLegal(`${pieceType} ${caseFacts}`);

    // Constrói prompt detalhado
    let contextBlock = `\n# DADOS PARA A PEÇA\n\n`;
    contextBlock += `**Tipo de peça:** ${pieceType}\n\n`;
    if (piece) {
      contextBlock += `**Fundamento legal:** ${piece.legalBasis}\n`;
      contextBlock += `**Prazo:** ${piece.deadline}\n`;
      contextBlock += `**Endereçamento:** ${piece.addressedTo}\n`;
      contextBlock += `**Dica estratégica:** ${piece.strategyHint}\n\n`;
    }
    if (clientData) contextBlock += `**Dados do cliente:** ${clientData}\n\n`;
    if (courtAddress) contextBlock += `**Endereçamento específico:** ${courtAddress}\n\n`;
    if (caseNumber) contextBlock += `**Número do processo:** ${caseNumber}\n\n`;
    contextBlock += `**FATOS DO CASO:**\n${caseFacts}\n\n`;
    if (additionalContext) contextBlock += `**Contexto adicional:** ${additionalContext}\n\n`;

    if (localResults.length > 0) {
      contextBlock += `\n# BASE LEGAL APLICÁVEL (CP/CPP/CF)\n${localResults.map(a =>
        `${a.code} art. ${a.article}${a.title ? ` — ${a.title}` : ""}: ${a.text}`
      ).join("\n\n")}\n\n`;
    }

    if (searchResults.length > 0) {
      contextBlock += `\n# JURISPRUDÊNCIA E MODELOS DA WEB (busca em tempo real)\n${searchResults.map((r, i) =>
        `[${i + 1}] ${r.title}\nURL: ${r.url}\nSnippet: ${r.snippet}`
      ).join("\n\n")}\n\n`;
    }

    contextBlock += `\n# INSTRUÇÃO FINAL\nRedija agora a peça "${pieceType}" completa, com endereçamento, qualificação, fatos, fundamentação (citando doutrina e base legal) e pedido. Não invente jurisprudência específica — se não souber o número do precedente, descreva a tese. Mantenha o português jurídico brasileiro. Não escreva comentários fora da peça.`;

    const messages = [
      { role: "system" as const, content: SYSTEM_PROMPT_PIECE },
      { role: "user" as const, content: contextBlock },
    ];

    const pieceContent = await chatWithGLM(messages, { temperature: 0.4, maxTokens: 6000 });

    return NextResponse.json({
      piece: pieceContent,
      pieceType,
      pieceInfo: piece ? {
        id: piece.id,
        name: piece.name,
        category: piece.category,
        legalBasis: piece.legalBasis,
        deadline: piece.deadline,
        addressedTo: piece.addressedTo,
        strategyHint: piece.strategyHint,
      } : null,
      sources: { web: searchResults, local: localResults },
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error("Piece generator API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
