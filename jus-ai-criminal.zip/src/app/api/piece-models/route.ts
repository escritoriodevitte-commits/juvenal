import { NextRequest, NextResponse } from "next/server";
import { webSearch } from "@/lib/zai-service";
import { getPieceById } from "@/lib/piece-catalog";

export const runtime = "nodejs";
export const maxDuration = 30;

/**
 * POST /api/piece-models
 * Busca modelos e exemplos reais de uma peça criminal na web.
 * Retorna URLs e snippets de modelos publicados (JusBrasil, Juspodivm, etc.)
 */
export async function POST(req: NextRequest) {
  try {
    const { pieceId } = await req.json();
    if (!pieceId) {
      return NextResponse.json({ error: "pieceId é obrigatório" }, { status: 400 });
    }

    const piece = getPieceById(pieceId);
    if (!piece) {
      return NextResponse.json({ error: "Peça não encontrada no catálogo" }, { status: 404 });
    }

    // Busca modelos e exemplos
    const queries = [
      piece.searchQuery,
      `${piece.name} modelo petição criminal exemplo prática`,
      `${piece.name} ${piece.legalBasis} jurisprudência STJ`,
    ];

    const allResults: any[] = [];
    const seenUrls = new Set<string>();

    for (const q of queries) {
      const results = await webSearch(q, 5);
      for (const r of results) {
        if (r.url && !seenUrls.has(r.url)) {
          seenUrls.add(r.url);
          allResults.push({
            ...r,
            queryType: q === queries[0] ? "modelo" : q === queries[1] ? "peticao" : "jurisprudencia",
          });
        }
      }
      if (allResults.length >= 12) break;
    }

    return NextResponse.json({
      piece: {
        id: piece.id,
        name: piece.name,
        category: piece.category,
        legalBasis: piece.legalBasis,
        description: piece.description,
        deadline: piece.deadline,
        addressedTo: piece.addressedTo,
        strategyHint: piece.strategyHint,
      },
      models: allResults,
      total: allResults.length,
    });
  } catch (err: any) {
    console.error("Piece models API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
