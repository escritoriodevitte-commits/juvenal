import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get("caseId");
    const pieces = await db.piece.findMany({
      where: caseId ? { caseId } : undefined,
      orderBy: { updatedAt: "desc" },
      include: { case: { select: { title: true } } },
    });
    return NextResponse.json({ pieces });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { caseId, title, pieceType, content, jurisprudence } = await req.json();
    if (!caseId || !title || !pieceType || !content) {
      return NextResponse.json({ error: "caseId, title, pieceType e content são obrigatórios" }, { status: 400 });
    }
    const piece = await db.piece.create({
      data: { caseId, title, pieceType, content, jurisprudence: jurisprudence || null },
    });
    return NextResponse.json({ piece });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
