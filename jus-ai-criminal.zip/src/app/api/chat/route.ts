import { NextRequest, NextResponse } from "next/server";
import { chatWithGLM, chatWithGLMStream, webSearch, shouldSearchWeb } from "@/lib/zai-service";
import { SYSTEM_PROMPT_CHAT } from "@/lib/persona";
import { searchLocalLegal } from "@/lib/legal-database";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const { messages, conversationId, useSearch = true } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "messages é obrigatório" }, { status: 400 });
    }

    // Detecta se precisa buscar na web
    const lastUserMsg = [...messages].reverse().find(m => m.role === "user");
    let searchResults: any[] = [];
    let localResults: any[] = [];

    if (useSearch && lastUserMsg) {
      const { shouldSearch, query } = shouldSearchWeb(lastUserMsg.content);
      if (shouldSearch) {
        searchResults = await webSearch(query, 5);
      }
      // Sempre busca na base local CP/CPP
      localResults = searchLocalLegal(lastUserMsg.content);
    }

    // Constrói contexto de sistema
    let systemPrompt = SYSTEM_PROMPT_CHAT;

    if (localResults.length > 0) {
      const localContext = localResults.map(art =>
        `**${art.code} art. ${art.article}${art.title ? ` — ${art.title}` : ""}**\n${art.text}${art.note ? `\nNota: ${art.note}` : ""}`
      ).join("\n\n");
      systemPrompt += `\n\n# BASE LEGAL LOCAL (CP/CPP/CF)\nAqui estão artigos relevantes da base local que você deve citar quando apropriado:\n\n${localContext}`;
    }

    if (searchResults.length > 0) {
      const searchContext = searchResults.map((r, i) =>
        `[${i + 1}] ${r.title}\nURL: ${r.url}\nSnippet: ${r.snippet}`
      ).join("\n\n");
      systemPrompt += `\n\n# JURISPRUDÊNCIA E FONTES DA WEB (busca em tempo real)\nResultados de busca atualizados:\n\n${searchContext}\n\nCite as fontes quando usar informações desses resultados. Use o formato [número] para referenciar.`;
    }

    // Salva mensagem do usuário se houver conversationId
    if (conversationId && lastUserMsg) {
      await db.message.create({
        data: {
          conversationId,
          role: "user",
          content: lastUserMsg.content,
        },
      });
    }

    // Prepara mensagens para o LLM
    const llmMessages = [
      { role: "system" as const, content: systemPrompt },
      ...messages.filter(m => m.role !== "system").map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    // Stream de resposta
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        let fullResponse = "";
        try {
          for await (const chunk of chatWithGLMStream(llmMessages)) {
            fullResponse += chunk;
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "chunk", content: chunk })}\n\n`));
          }

          // Envia fontes ao final
          if (searchResults.length > 0 || localResults.length > 0) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({
              type: "sources",
              web: searchResults,
              local: localResults,
            })}\n\n`));
          }

          // Salva resposta do assistente
          if (conversationId) {
            await db.message.create({
              data: {
                conversationId,
                role: "assistant",
                content: fullResponse,
                sources: JSON.stringify({ web: searchResults, local: localResults }),
              },
            });

            // Atualiza título da conversa se for a primeira mensagem
            const count = await db.message.count({ where: { conversationId } });
            if (count <= 2) {
              const title = lastUserMsg?.content.slice(0, 60) + (lastUserMsg?.content.length > 60 ? "..." : "");
              await db.conversation.update({
                where: { id: conversationId },
                data: { title },
              });
            }
          }

          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "done" })}\n\n`));
          controller.close();
        } catch (err: any) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "error", error: err.message })}\n\n`));
          controller.close();
        }
      },
    });

    return new NextResponse(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (err: any) {
    console.error("Chat API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
