import { NextRequest, NextResponse } from "next/server";
import { searchLocalLegal } from "@/lib/legal-database";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const { query } = await req.json();
    if (!query) {
      return NextResponse.json({ error: "query é obrigatório" }, { status: 400 });
    }
    const results = searchLocalLegal(query);
    return NextResponse.json({ results, query, total: results.length });
  } catch (err: any) {
    console.error("Legal search API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
