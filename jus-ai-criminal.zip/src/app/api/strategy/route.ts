import { NextRequest, NextResponse } from "next/server";
import { chatWithGLM, webSearch } from "@/lib/zai-service";
import { SYSTEM_PROMPT_STRATEGY } from "@/lib/persona";
import { searchLocalLegal } from "@/lib/legal-database";

export const runtime = "nodejs";
export const maxDuration = 90;

export async function POST(req: NextRequest) {
  try {
    const { caseDescription, crime, clientGoals, additionalContext, useSearch = true } = await req.json();

    if (!caseDescription) {
      return NextResponse.json({ error: "caseDescription é obrigatório" }, { status: 400 });
    }

    let searchResults: any[] = [];
    let localResults: any[] = [];

    if (useSearch) {
      const searchQuery = `defesa criminal ${crime || ""} Brasil STJ STF jurisprudência`;
      searchResults = await webSearch(searchQuery, 5);
    }
    localResults = searchLocalLegal(`${crime || ""} ${caseDescription}`);

    let contextBlock = `\n# CASO PARA ANÁLISE ESTRATÉGICA\n\n`;
    if (crime) contextBlock += `**Tipificação alegada:** ${crime}\n\n`;
    contextBlock += `**DESCRIÇÃO DO CASO:**\n${caseDescription}\n\n`;
    if (clientGoals) contextBlock += `**Objetivos do cliente:** ${clientGoals}\n\n`;
    if (additionalContext) contextBlock += `**Contexto adicional:** ${additionalContext}\n\n`;

    if (localResults.length > 0) {
      contextBlock += `\n# BASE LEGAL APLICÁVEL\n${localResults.map(a =>
        `${a.code} art. ${a.article}${a.title ? ` — ${a.title}` : ""}: ${a.text}`
      ).join("\n\n")}\n\n`;
    }

    if (searchResults.length > 0) {
      contextBlock += `\n# JURISPRUDÊNCIA RECENTE (busca web)\n${searchResults.map((r, i) =>
        `[${i + 1}] ${r.title}\nURL: ${r.url}\nSnippet: ${r.snippet}`
      ).join("\n\n")}\n\n`;
    }

    contextBlock += `\n# INSTRUÇÃO FINAL\nElabore a estratégia defensiva completa segundo a metodologia de 4 blocos (FATOS, DIREITO, PROVA, NARRATIVA). Inclua ao final: TESE RECOMENDADA, PEÇAS NECESSÁRIAS, RISCOS E ALTERNATIVAS, BIBLIOGRAFIA SUGERIDA. Não invente jurisprudência específica — descreva a tese.`;

    const messages = [
      { role: "system" as const, content: SYSTEM_PROMPT_STRATEGY },
      { role: "user" as const, content: contextBlock },
    ];

    const strategy = await chatWithGLM(messages, { temperature: 0.5, maxTokens: 6000 });

    return NextResponse.json({
      strategy,
      sources: { web: searchResults, local: localResults },
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error("Strategy API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
