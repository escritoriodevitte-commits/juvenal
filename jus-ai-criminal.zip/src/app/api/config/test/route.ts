import { NextRequest, NextResponse } from "next/server";
import { getZAIInstance } from "@/lib/zai-service";

export const runtime = "nodejs";
export const maxDuration = 30;

// POST /api/config/test — testa a conexão com a chave atual
export async function POST() {
  try {
    const zai = await getZAIInstance();
    const response = await zai.chat.completions.create({
      messages: [
        { role: "user", content: "Responda apenas: OK" },
      ],
      model: "glm-5.2",
      max_tokens: 10,
      temperature: 0,
    });
    const content = response.choices?.[0]?.message?.content || "";
    return NextResponse.json({
      success: true,
      message: "Conexão bem-sucedida com o Z.AI",
      sample: content,
      model: response.model || "glm-5.2",
      tokens: response.usage?.total_tokens || 0,
    });
  } catch (err: any) {
    console.error("Config test error:", err);
    const msg = err?.message || "Falha na conexão";
    const isSSLError = msg.includes("certificate") || msg.includes("SSL") || msg.includes("UNKNOWN_CERT");
    return NextResponse.json(
      {
        success: false,
        error: msg,
        hint: isSSLError
          ? "Erro de certificado SSL — comum em sandbox. Use o config do sandbox (Resetar) ou faça deploy próprio."
          : "Verifique baseUrl e apiKey. Para Z.AI oficial: baseUrl=https://api.z.ai/api/v1",
        isSandbox: isSSLError,
      },
      { status: 502 }
    );
  }
}
