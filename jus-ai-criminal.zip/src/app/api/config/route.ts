import { NextRequest, NextResponse } from "next/server";
import {
  readProjectConfig,
  writeProjectConfig,
  deleteProjectConfig,
  getActiveConfigMode,
} from "@/lib/zai-service";

export const runtime = "nodejs";

// GET /api/config — retorna status atual (mascarado)
export async function GET() {
  const config = readProjectConfig();
  const mode = getActiveConfigMode();
  return NextResponse.json({
    usingCustom: config.exists,
    mode, // "env-var" | "project-file" | "system-fallback"
    config: config.exists ? config.masked : null,
    source: config.masked?.source || (mode === "system-fallback" ? "system" : mode),
    fallback: "/etc/.z-ai-config (sandbox)",
    isServerless: process.env.VERCEL === "1" || process.env.VERCEL_ENV !== undefined,
  });
}

// POST /api/config — salva novo config (apenas funciona em dev local, não em serverless)
export async function POST(req: NextRequest) {
  try {
    const { baseUrl, apiKey, userId } = await req.json();
    if (!baseUrl || !apiKey) {
      return NextResponse.json(
        { error: "baseUrl e apiKey são obrigatórios" },
        { status: 400 }
      );
    }
    if (!baseUrl.startsWith("http://") && !baseUrl.startsWith("https://")) {
      return NextResponse.json(
        { error: "baseUrl deve começar com http:// ou https://" },
        { status: 400 }
      );
    }
    if (apiKey.length < 8) {
      return NextResponse.json(
        { error: "apiKey parece curta demais — verifique" },
        { status: 400 }
      );
    }
    writeProjectConfig({ baseUrl, apiKey, userId });
    return NextResponse.json({
      success: true,
      message: "Config salvo em .z-ai-config no projeto",
    });
  } catch (err: any) {
    // Mensagem especial para serverless
    if (err.message?.includes("read-only") || err.message?.includes("EROFS")) {
      return NextResponse.json({
        error: "Em produção (Vercel/serverless), use variáveis de ambiente: ZAI_API_KEY, ZAI_BASE_URL. Configure no painel da Vercel → Settings → Environment Variables.",
      }, { status: 403 });
    }
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// DELETE /api/config — remove config do projeto, volta para o do sistema
export async function DELETE() {
  deleteProjectConfig();
  return NextResponse.json({
    success: true,
    message: "Config removido — voltando para /etc/.z-ai-config",
  });
}
