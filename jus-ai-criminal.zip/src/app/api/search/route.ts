import { NextRequest, NextResponse } from "next/server";
import { webSearch } from "@/lib/zai-service";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const { query, num = 8 } = await req.json();
    if (!query) {
      return NextResponse.json({ error: "query é obrigatório" }, { status: 400 });
    }
    const results = await webSearch(query, num);
    return NextResponse.json({ results, query });
  } catch (err: any) {
    console.error("Search API error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
