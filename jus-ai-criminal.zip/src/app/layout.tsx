import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "JUS·AI Criminal — Agente Jurídico Sênior",
  description: "Super agente jurídico criminalista com GLM 5.2 — busca de jurisprudência, geração de peças penais e estratégia defensiva. Persona: Aury Lopes Jr + Badaró + Bottini + Nucci.",
  keywords: ["direito penal", "advogado criminalista", "jurisprudência", "STJ", "STF", "peças penais", "habeas corpus", "tribunal do júri"],
  authors: [{ name: "JUS·AI Criminal" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
