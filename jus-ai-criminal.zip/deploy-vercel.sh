#!/usr/bin/env bash
# ============================================================
# JUS·AI Criminal — Script de deploy para Vercel
# ============================================================
# Uso: bash deploy-vercel.sh
# ============================================================

set -e

echo "🏛️  JUS·AI Criminal — Deploy para Vercel"
echo "========================================="

# Verifica se git está inicializado
if [ ! -d .git ]; then
  echo "📦 Inicializando git repo..."
  git init
fi

# Verifica se há mudanças não commitadas
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "📝 Committando mudanças..."
  git add -A
  git commit -m "Deploy Vercel - $(date +'%Y-%m-%d %H:%M')"
fi

# Verifica se há remote
if ! git remote get-url origin >/dev/null 2>&1; then
  echo ""
  echo "⚠️  Você ainda não configurou o GitHub remote."
  echo ""
  echo "Passos:"
  echo "1. Crie um repositório no GitHub: https://github.com/new"
  echo "   Nome sugerido: jus-ai-criminal"
  echo "   NÃO adicione README/gitignore (o repo já tem)"
  echo ""
  echo "2. Copie a URL do repositório (ex: https://github.com/SEU_USER/jus-ai-criminal.git)"
  echo ""
  echo "3. Rode os comandos:"
  echo "   git remote add origin https://github.com/SEU_USER/jus-ai-criminal.git"
  echo "   git branch -M main"
  echo "   git push -u origin main"
  echo ""
  echo "4. Depois rode novamente este script para continuar."
  exit 0
fi

# Push para GitHub
echo "🚀 Fazendo push para GitHub..."
git push origin main

echo ""
echo "✅ Push concluído!"
echo ""
echo "Agora:"
echo "1. Acesse https://vercel.com/new"
echo "2. Import o repositório jus-ai-criminal"
echo "3. Configure as variáveis de ambiente:"
echo "   - ZAI_API_KEY (obrigatório — pegue em https://z.ai/manage-apikey/apikey-list)"
echo "   - ZAI_BASE_URL = https://api.z.ai/api/v1"
echo "   - DATABASE_URL (pegue no Neon, Supabase, ou Vercel Postgres)"
echo "4. Antes do deploy, troque o schema do Prisma para Postgres:"
echo "   cp prisma/schema.vercel.prisma prisma/schema.prisma"
echo "   git add . && git commit -m 'switch to postgres' && git push"
echo "5. Clique em Deploy"
echo ""
echo "📖 Veja README-VERCEL.md para detalhes completos."
