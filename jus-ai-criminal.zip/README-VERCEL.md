# 🚀 Deploy na Vercel — JUS·AI Criminal

Guia completo para fazer deploy do JUS·AI Criminal na Vercel e usar sua própria chave Z.AI API.

## ✅ Pré-requisitos

1. Conta na [Vercel](https://vercel.com) (grátis)
2. Conta no [GitHub](https://github.com) (grátis)
3. Chave da Z.AI API (obtenha em https://z.ai/manage-apikey/apikey-list)
4. (Opcional) Conta no [Neon](https://neon.tech) ou [Supabase](https://supabase.com) para banco Postgres grátis

---

## 📋 Passo a passo

### Passo 1 — Subir o código para o GitHub

```bash
# No diretório do projeto
git init
git add .
git commit -m "JUS·AI Criminal — agente jurídico criminalista"

# Crie um repositório no GitHub chamado "jus-ai-criminal" (sem README/gitignore)
# Depois rode:
git remote add origin https://github.com/SEU_USUARIO/jus-ai-criminal.git
git branch -M main
git push -u origin main
```

### Passo 2 — Conectar na Vercel

1. Acesse https://vercel.com/new
2. Clique em **"Import Git Repository"**
3. Selecione seu repositório `jus-ai-criminal`
4. Configurações automáticas detectadas:
   - **Framework Preset**: Next.js
   - **Build Command**: `next build` (já no package.json)
   - **Output Directory**: `.next`
   - **Install Command**: `bun install` ou `npm install`
5. **NÃO clique em Deploy ainda** — primeiro configure as variáveis de ambiente (Passo 3)

### Passo 3 — Configurar variáveis de ambiente

Na mesma tela de deploy, expanda **"Environment Variables"** e adicione:

| Nome | Valor | Obrigatório |
|------|-------|-------------|
| `ZAI_API_KEY` | `sua_chave_zai_aqui` | ✅ Sim |
| `ZAI_BASE_URL` | `https://api.z.ai/api/v1` | Opcional (default já é este) |
| `ZAI_USER_ID` | `seu_user_id_opcional` | Opcional |
| `DATABASE_URL` | `postgresql://...` (ver Passo 4) | ✅ Sim |

⚠️ **Importante**: Marque as variáveis como **Production + Preview + Development**.

### Passo 4 — Configurar banco de dados Postgres

O SQLite não funciona na Vercel (filesystem read-only). Use Postgres.

#### Opção A — Neon (recomendado, grátis, 0.5GB)

1. Acesse https://neon.tech e crie conta
2. Clique em **"New Project"**
3. Escolha um nome (ex: `jus-ai`)
4. Selecione região próxima (ex: São Paulo / us-east-1)
5. Clique em **"Create project"**
6. Copie a **connection string** que aparece (formato: `postgresql://user:pass@host/db?sslmode=require`)
7. Use essa string como valor de `DATABASE_URL` na Vercel

#### Opção B — Vercel Postgres (mais integrado, grátis, 256MB)

1. No painel da Vercel, vá em **Storage → Create Database**
2. Selecione **Postgres**
3. Nome: `jus-ai-db`
4. Region: mesma do projeto
5. Clique em **Create**
6. A Vercel automaticamente injeta `DATABASE_URL` no projeto — não precisa adicionar manualmente

#### Opção C — Supabase (grátis, 500MB)

1. Acesse https://supabase.com
2. Crie novo projeto
3. Em **Project Settings → Database → Connection string → URI**, copie a string
4. Use como `DATABASE_URL` na Vercel

### Passo 5 — Trocar schema do Prisma para Postgres

Antes do primeiro deploy, troque o schema do SQLite para Postgres:

```bash
# Substitua o schema.prisma pelo schema.vercel.prisma
cp prisma/schema.vercel.prisma prisma/schema.prisma

# Commit e push
git add prisma/schema.prisma
git commit -m "Switch to Postgres schema for Vercel"
git push
```

### Passo 6 — Deploy!

1. Volte na tela da Vercel
2. Clique em **Deploy**
3. Aguarde ~2-3 minutos (build + postinstall do Prisma)
4. Acesse a URL gerada (ex: `jus-ai-criminal.vercel.app`)

### Passo 7 — Criar tabelas no banco (uma vez só)

Após o primeiro deploy, as tabelas precisam ser criadas. Duas opções:

#### Opção A — Pelo painel Neon/Supabase
Execute o SQL do Prisma manualmente (mais complexo).

#### Opção B — Pelo terminal local (recomendado)

```bash
# Clone o repo localmente (se ainda não tem)
git clone https://github.com/SEU_USUARIO/jus-ai-criminal.git
cd jus-ai-criminal

# Instale dependências
bun install  # ou npm install

# Crie arquivo .env com a mesma DATABASE_URL da Vercel
echo "DATABASE_URL=postgresql://sua_url_do_neon_aqui" > .env
echo "ZAI_API_KEY=sua_chave_aqui" >> .env

# Rode o comando para criar tabelas
bun run db:push  # ou npx prisma db push
```

Pronto! O app está no ar.

---

## 🎯 Como usar em produção

1. Acesse sua URL da Vercel (ex: `jus-ai-criminal.vercel.app`)
2. Vá na aba **Config** — deve mostrar "Modo env var ativo" (suas variáveis da Vercel)
3. Clique em **Testar** para validar a conexão com o GLM 5.2
4. Use normalmente: Chat, Peças, Estratégia, Audiências, Casos

---

## 🔄 Atualizações

Para atualizar o app com novos commits:

```bash
git add .
git commit -m "descrição da mudança"
git push
```

A Vercel faz redeploy automático a cada push na branch `main`.

---

## 🐛 Solução de problemas

### Erro: "Configuration file not found or invalid"
- Verifique se `ZAI_API_KEY` está configurada na Vercel (Settings → Environment Variables)
- Faça redeploy após adicionar

### Erro: "Prisma Client not found"
- O `postinstall` roda `prisma generate` automaticamente
- Se falhar, adicione `"vercel:build": "prisma generate && next build"` como Build Command no painel

### Erro: "Database connection failed"
- Verifique a `DATABASE_URL` (formato correto: `postgresql://user:pass@host:5432/db?sslmode=require`)
- No Neon, certifique-se de incluir `?sslmode=require` no final

### Chat funciona mas busca web não retorna resultados
- O `z-ai-web-dev-sdk` faz web search via API — pode haver rate limit
- Verifique seu plano da Z.AI API

### Audiências não salvam notas
- As notas são salvas em `localStorage` do navegador — funcionam normalmente
- Limpe o cache do navegador se houver problemas

---

## 📦 Estrutura técnica do deploy

```
jus-ai-criminal/
├── prisma/
│   ├── schema.prisma          # Schema atual (SQLite para dev local)
│   └── schema.vercel.prisma   # Schema Postgres para Vercel
├── src/
│   ├── app/                   # Rotas Next.js (App Router)
│   │   ├── api/               # APIs serverless
│   │   ├── layout.tsx
│   │   └── page.tsx           # UI principal
│   ├── components/jusai/      # 7 componentes de aba
│   └── lib/
│       ├── zai-service.ts     # GLM 5.2 + web search + reader (env vars)
│       ├── persona.ts         # 3 system prompts
│       ├── legal-database.ts  # Base local CP/CPP/CF
│       ├── piece-catalog.ts   # 41 peças criminais
│       └── hearing-catalog.ts # 5 tipos de audiência + perguntas
├── .env.example               # Template de variáveis
├── .gitignore                 # Exclui .z-ai-config, .env, db/
├── next.config.ts             # Detecta Vercel automaticamente
├── package.json               # postinstall: prisma generate
└── README-VERCEL.md           # Este arquivo
```

---

## 💰 Custos estimados (uso moderado)

| Serviço | Free tier | Pago |
|---------|-----------|------|
| **Vercel** (Hobby) | 100GB bandwidth/mês | $20/mês (Pro) |
| **Neon** (Free) | 0.5GB storage, 100h compute/mês | $19/mês |
| **Z.AI API** | Créditos iniciais | Por uso (~$0.01/1k tokens) |

Para uso pessoal/profissional individual, o free tier cobre tranquilamente.

---

## 🆘 Suporte

Se algo der errado:

1. **Logs da Vercel**: Painel do projeto → Deployments → clique no deploy → "Build Logs" ou "Runtime Logs"
2. **Status da API Z.AI**: https://z.ai/status
3. **Prisma erro comum**: https://www.prisma.io/docs/orm/troubleshooting-orm

---

**Feito por um advogado, para advogados.** 🏛️
